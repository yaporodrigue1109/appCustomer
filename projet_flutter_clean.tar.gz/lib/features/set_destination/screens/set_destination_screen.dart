// import 'dart:async';
// import 'dart:math' as math;
// import 'package:flutter/material.dart';
// import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
// import 'package:get/get.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:ride_sharing_user_app/features/dashboard/screens/dashboard_screen.dart';
// import 'package:ride_sharing_user_app/features/parcel/controllers/parcel_controller.dart';
// import 'package:ride_sharing_user_app/features/ride/widgets/ride_category.dart';
// import 'package:ride_sharing_user_app/features/set_destination/widget/pick_location_widget.dart';
// import 'package:ride_sharing_user_app/features/set_destination/widget/pickup_time_date_widget.dart';
// import 'package:ride_sharing_user_app/features/set_destination/widget/process_button_widget.dart';
// import 'package:ride_sharing_user_app/features/set_destination/widget/reservation_note_widget.dart';
// import 'package:ride_sharing_user_app/helper/route_helper.dart';
// import 'package:ride_sharing_user_app/localization/localization_controller.dart';
// import 'package:ride_sharing_user_app/util/dimensions.dart';
// import 'package:ride_sharing_user_app/util/images.dart';
// import 'package:ride_sharing_user_app/util/styles.dart';
// import 'package:ride_sharing_user_app/features/address/domain/models/address_model.dart';
// import 'package:ride_sharing_user_app/features/location/controllers/location_controller.dart';
// import 'package:ride_sharing_user_app/features/location/view/pick_map_screen.dart';
// import 'package:ride_sharing_user_app/features/map/controllers/map_controller.dart';
// import 'package:ride_sharing_user_app/features/ride/controllers/ride_controller.dart';
// import 'package:ride_sharing_user_app/features/splash/controllers/config_controller.dart';
// import 'package:ride_sharing_user_app/common_widgets/app_bar_widget.dart';
// import 'package:ride_sharing_user_app/common_widgets/body_widget.dart';
// import 'package:ride_sharing_user_app/common_widgets/divider_widget.dart';
// import 'package:ride_sharing_user_app/features/home/domain/models/categoty_model.dart';
// import 'package:ride_sharing_user_app/features/home/controllers/category_controller.dart';
// import 'package:ride_sharing_user_app/helper/display_helper.dart';
// import 'package:ride_sharing_user_app/features/map/screens/map_screen.dart';

// class SetDestinationScreen extends StatefulWidget {
//   final Address? address;
//   final String? searchText;
//   final RideType rideType;

//   const SetDestinationScreen({
//     super.key,
//     this.address,
//     this.searchText,
//     this.rideType = RideType.regularRide,
//   });

//   @override
//   State<SetDestinationScreen> createState() => _SetDestinationScreenState();
// }

// class _SetDestinationScreenState extends State<SetDestinationScreen> {
//   FocusNode pickLocationFocus = FocusNode();
//   FocusNode destinationLocationFocus = FocusNode();
//   ScrollController scrollController = ScrollController();
//   double dialogTopPosition = 0;
//   double bottomWhiteSpace = 0;
//   var keyboardVisibilityController = KeyboardVisibilityController();
//   late StreamSubscription<bool> keyboardSubscription;
//   final GlobalKey _key = GlobalKey();
//   bool _isInitialized = false;
  
//   // Timer pour le debounce
//   Timer? _debounceTimer;
  
//   // Pour éviter les appels multiples
//   bool _isSearchTriggered = false;
  
//   // Pour suivre quand une adresse a été sélectionnée
//   bool _pickupSelected = false;
//   bool _destinationSelected = false;

//   @override
//   void initState() {
//     super.initState();

//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       _initializeScreen();
//       // Initialiser l'état "commander pour un autre" à false
//       Get.find<LocationController>().resetRideForOther();
//       Get.find<RideController>().clearBeneficiaryInfo();
      
//       // DÉMARRER l'actualisation automatique de la position
//       Get.find<LocationController>().startAutoLocationUpdate();
      
//       // Définir la position actuelle comme point de départ
//       _setInitialPickupLocation();
      
//       // Écouter les changements dans les adresses (quand l'utilisateur sélectionne)
//       _setupAddressListeners();
//     });

//     Get.find<RideController>().setRideType(widget.rideType);
//     Get.find<LocationController>().initAddLocationData();
//     Get.find<LocationController>().initTextControllers();
//     Get.find<RideController>().clearExtraRoute();
//     Get.find<MapController>().initializeData();
//     Get.find<RideController>().initData();
//     Get.find<ParcelController>().updatePaymentPerson(false, notify: false);

//     if (widget.address != null) {
//       Get.find<LocationController>().setDestination(widget.address);
//     }
//     if (widget.searchText != null) {
//       Get.find<LocationController>().setDestination(Address(address: widget.searchText));
//       Future.delayed(const Duration(seconds: 1)).then((_) {
//         Get.find<LocationController>().searchLocation(
//           Get.context!,
//           widget.searchText ?? '',
//           type: LocationType.to,
//         );
//       });
//     }

//     keyboardSubscription =
//         keyboardVisibilityController.onChange.listen((bool visible) {
//           if (!visible) {
//             bottomWhiteSpace = 0;
//           }
//         });
//   }

//   // AJOUT : Écouter les changements d'adresses (quand l'utilisateur sélectionne une suggestion)
//   void _setupAddressListeners() {
//   final locationController = Get.find<LocationController>();
  
//   // Utiliser un Worker avec une fonction qui retourne la valeur
//   ever<Address?>(locationController.fromAddress as Rx<Address?>, (address) {
//     if (address != null && address.address != null && address.address!.isNotEmpty) {
//       print("📍 Adresse de départ sélectionnée: ${address.address}");
//       _pickupSelected = true;
//       _checkAndTriggerSearch();
//     }
//   });
  
//   ever<Address?>(locationController.toAddress as Rx<Address?>, (address) {
//     if (address != null && address.address != null && address.address!.isNotEmpty) {
//       print("📍 Adresse de destination sélectionnée: ${address.address}");
//       _destinationSelected = true;
//       _checkAndTriggerSearch();
//     }
//   });
// }

//   // AJOUT : Vérifier si les deux adresses sont sélectionnées et lancer la recherche
//   void _checkAndTriggerSearch() {
//     final locationController = Get.find<LocationController>();
    
//     bool hasValidPickup = locationController.fromAddress != null && 
//                          locationController.fromAddress!.address != null &&
//                          locationController.fromAddress!.address!.isNotEmpty;
    
//     bool hasValidDestination = locationController.toAddress != null && 
//                               locationController.toAddress!.address != null &&
//                               locationController.toAddress!.address!.isNotEmpty;
    
//     print("🔍 Vérification recherche automatique:");
//     print("  - Départ valide: $hasValidPickup (sélectionné: $_pickupSelected)");
//     print("  - Destination valide: $hasValidDestination (sélectionnée: $_destinationSelected)");
    
//     if (hasValidPickup && hasValidDestination && _pickupSelected && _destinationSelected) {
//       // Annuler le timer précédent
//       _debounceTimer?.cancel();
      
//       // Petit délai pour laisser le temps à l'UI de se mettre à jour
//       _debounceTimer = Timer(const Duration(milliseconds: 300), () {
//         _autoSearchRide();
//       });
//     }
//   }

//   // Méthode pour lancer automatiquement la recherche
//   Future<void> _autoSearchRide() async {
//     // Éviter les appels multiples
//     if (_isSearchTriggered) return;
    
//     final locationController = Get.find<LocationController>();
//     final rideController = Get.find<RideController>();
//     final configController = Get.find<ConfigController>();
    
//     // Vérifier la maintenance
//     if (configController.config!.maintenanceMode != null &&
//         configController.config!.maintenanceMode!.maintenanceStatus == 1 &&
//         configController.config!.maintenanceMode!.selectedMaintenanceSystem!.userApp == 1) {
//       showCustomSnackBar('maintenance_mode_on_for_ride'.tr, isError: true);
//       return;
//     }
    
//     // Vérifier si une recherche est déjà en cours
//     if (rideController.loading) return;
    
//     // Marquer comme déclenché
//     _isSearchTriggered = true;
    
//     print("🚀 Lancement automatique de la recherche");
//     print("📍 Départ: ${locationController.fromAddress?.address}");
//     print("📍 Destination: ${locationController.toAddress?.address}");
    
//     // Lancer la recherche
//     var response = await rideController.getEstimatedFare(false);
    
//     if (response.statusCode == 200) {
//       print("✅ Recherche réussie, navigation vers MapScreen");
//       // Navigation vers l'écran map
//       Get.to(() => const MapScreen(
//         fromScreen: MapScreenType.ride,
//         isShowCurrentPosition: false,
//       ));
//       rideController.updateRideCurrentState(RideState.initial);
//     } else {
//       print("❌ Échec de la recherche");
//       _isSearchTriggered = false; // Réinitialiser en cas d'échec
//     }
//   }

//   // Méthode pour définir la position actuelle comme point de départ
//   Future<void> _setInitialPickupLocation() async {
//     try {
//       final locationController = Get.find<LocationController>();
      
//       // Vérifier si on a déjà une position
//       if (locationController.position.latitude != 0 && 
//           locationController.position.longitude != 0) {
        
//         // Obtenir l'adresse à partir des coordonnées
//         String address = await locationController.getAddressFromGeocode(
//           LatLng(
//             locationController.position.latitude,
//             locationController.position.longitude
//           )
//         );
        
//         // Créer l'adresse
//         Address currentAddress = Address(
//           latitude: locationController.position.latitude,
//           longitude: locationController.position.longitude,
//           address: address,
//         );
        
//         // Définir comme point de départ
//         locationController.setPickUp(currentAddress);
//         locationController.resetRideForOtherPromptFlag(); // Réinitialiser le flag
//         _pickupSelected = true; // Marquer comme sélectionné
//         print("📍 Position actuelle définie comme point de départ: $address");
//       }
//     } catch (e) {
//       print("❌ Erreur lors de la définition de la position initiale: $e");
//     }
//   }

//   void _initializeScreen() {
//     if (_isInitialized) return;

//     print("🚀 Initialisation de SetDestinationScreen");
//     print("📋 Type de trajet: ${widget.rideType}");

//     try {
//       final rideController = Get.find<RideController>();
//       final categoryController = Get.find<CategoryController>();

//       if (widget.rideType == RideType.regularRide) {
//         print("✅ Conservation de l'index actuel: ${rideController.rideCategoryIndex}");

//         if (categoryController.categoryList != null &&
//             categoryController.categoryList!.isNotEmpty) {

//           if (rideController.rideCategoryIndex >= categoryController.categoryList!.length) {
//             print("⚠️ Index invalide, réinitialisation à 0");
//             rideController.setRideCategoryIndex(0);
//           }
//         }
//       } else {
//         print("📅 Trajet programmé, index actuel: ${rideController.rideCategoryIndex}");
//       }

//       if (categoryController.categoryList != null) {
//         print("📋 Catégories disponibles:");
//         for (int i = 0; i < categoryController.categoryList!.length; i++) {
//           final cat = categoryController.categoryList![i];
//           print("   Index $i: ${cat.name} - ID: ${cat.id} - Image: ${cat.image}");
//         }
//       }

//       _isInitialized = true;
//       rideController.update();

//     } catch (e) {
//       print("❌ Erreur: $e");
//       Future.delayed(const Duration(milliseconds: 500), () {
//         _initializeScreen();
//       });
//     }
//   }

//   @override
//   void dispose() {
//     // Annuler le timer
//     _debounceTimer?.cancel();
    
//     // ARRÊTER l'actualisation automatique
//     Get.find<LocationController>().stopAutoLocationUpdate();
//     keyboardSubscription.cancel();
//     super.dispose();
//   }

//   // Widget indicateur de mise à jour de position amélioré
//   Widget _buildEnhancedLocationIndicator(LocationController locationController) {
//     bool isAutoTracking = !locationController.userModifiedManually;
    
//     return Container(
//       margin: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
//       padding: const EdgeInsets.symmetric(
//         horizontal: Dimensions.paddingSizeExtraSmall,
//         vertical: 2,
//       ),
//       decoration: BoxDecoration(
//         color: isAutoTracking 
//           ? Colors.blue.withOpacity(0.1)
//           : Colors.orange.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//       ),
//       child: Row(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           if (isAutoTracking) ...[
//             SizedBox(
//               width: 10,
//               height: 10,
//               child: CircularProgressIndicator(
//                 strokeWidth: 1.5,
//                 valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
//               ),
//             ),
//             const SizedBox(width: 4),
//             Text(
//               'Auto',
//               style: textRegular.copyWith(
//                 fontSize: 8,
//                 color: Colors.blue,
//               ),
//             ),
//           ] else ...[
//             Icon(
//               Icons.edit_location,
//               color: Colors.orange,
//               size: 10,
//             ),
//             const SizedBox(width: 4),
//             Text(
//               'Manuel',
//               style: textRegular.copyWith(
//                 fontSize: 8,
//                 color: Colors.orange,
//               ),
//             ),
//           ],
//         ],
//       ),
//     );
//   }

//   // Widget bouton pour réactiver le suivi automatique
//   Widget _buildAutoTrackingButton(LocationController locationController) {
//     // N'afficher le bouton que si l'utilisateur a modifié manuellement
//     if (!locationController.userModifiedManually || locationController.isRideForOther) return const SizedBox.shrink();
    
//     return Container(
//       margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           InkWell(
//             onTap: () async {
//               // Réactiver le suivi automatique
//               await locationController.resetToCurrentLocation();
//               _pickupSelected = true; // Marquer comme sélectionné
              
//               // Afficher un message de confirmation
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(
//                   content: Text('Position réinitialisée à votre position actuelle'),
//                   duration: const Duration(seconds: 2),
//                   backgroundColor: Colors.green,
//                 ),
//               );
//             },
//             child: Container(
//               padding: const EdgeInsets.symmetric(
//                 horizontal: Dimensions.paddingSizeDefault,
//                 vertical: Dimensions.paddingSizeExtraSmall,
//               ),
//               decoration: BoxDecoration(
//                 color: Colors.blue.withOpacity(0.1),
//                 borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                 border: Border.all(color: Colors.blue.withOpacity(0.3)),
//               ),
//               child: Row(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Icon(
//                     Icons.my_location,
//                     color: Colors.blue,
//                     size: 16,
//                   ),
//                   const SizedBox(width: Dimensions.paddingSizeExtraSmall),
//                   Text(
//                     'Utiliser ma position actuelle',
//                     style: textMedium.copyWith(
//                       fontSize: Dimensions.fontSizeSmall,
//                       color: Colors.blue,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

// // Widget pour demander si l'utilisateur veut commander pour quelqu'un d'autre
// Widget _buildRideForOtherPrompt(LocationController locationController) {
//   return Container(
//     margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
//     padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
//     decoration: BoxDecoration(
//       color: Theme.of(context).primaryColor.withOpacity(0.05),
//       borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
//       border: Border.all(
//         color: Theme.of(context).primaryColor.withOpacity(0.3),
//         width: 1,
//       ),
//     ),
//     child: Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Row(
//           children: [
//             Container(
//               padding: const EdgeInsets.all(8),
//               decoration: BoxDecoration(
//                 color: Theme.of(context).primaryColor.withOpacity(0.1),
//                 borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//               ),
//               child: Icon(
//                 Icons.help_outline,
//                 color: Theme.of(context).primaryColor,
//                 size: 20,
//               ),
//             ),
//             const SizedBox(width: Dimensions.paddingSizeSmall),
//             Expanded(
//               child: Text(
//                 'Cette course est pour vous ?',
//                 style: textSemiBold.copyWith(
//                   fontSize: Dimensions.fontSizeDefault,
//                 ),
//               ),
//             ),
//           ],
//         ),
//         const SizedBox(height: Dimensions.paddingSizeDefault),
//         Text(
//           'Vous avez modifié le point de départ à plus de 100 mètres de votre position actuelle. Souhaitez-vous commander pour quelqu\'un d\'autre ?',
//           style: textRegular.copyWith(
//             fontSize: Dimensions.fontSizeSmall,
//             color: Colors.grey[600],
//           ),
//         ),
//         const SizedBox(height: Dimensions.paddingSizeDefault),
//         Row(
//           children: [
//             Expanded(
//               child: InkWell(
//                 onTap: () {
//                   // OPTION 1: L'utilisateur veut commander pour lui-même
//                   print('👤 Option "Pour moi" sélectionnée');
                  
//                   // Marquer comme affiché pour ne plus réafficher dans cette session
//                   locationController.resetRideForOtherPromptFlag();
                  
//                   // Forcer une mise à jour pour fermer le prompt
//                   setState(() {});
                  
//                   // Afficher un petit message de confirmation
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     SnackBar(
//                       content: Text('Course pour vous-même'),
//                       duration: const Duration(seconds: 1),
//                       backgroundColor: Colors.green,
//                     ),
//                   );
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(
//                     vertical: Dimensions.paddingSizeSmall,
//                   ),
//                   decoration: BoxDecoration(
//                     color: Colors.grey[200],
//                     borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                   ),
//                   child: Center(
//                     child: Text(
//                       'Pour moi',
//                       style: textMedium.copyWith(
//                         color: Colors.grey[700],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             const SizedBox(width: Dimensions.paddingSizeSmall),
//             Expanded(
//               child: InkWell(
//                 onTap: () {
//                   // OPTION 2: L'utilisateur veut commander pour quelqu'un d'autre
//                   print('👥 Option "Pour quelqu\'un d\'autre" sélectionnée');
                  
//                   // Activer le mode "pour quelqu'un d'autre"
//                   locationController.setRideForOther(true);
                  
//                   // Forcer une mise à jour
//                   setState(() {});
//                 },
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(
//                     vertical: Dimensions.paddingSizeSmall,
//                   ),
//                   decoration: BoxDecoration(
//                     color: Theme.of(context).primaryColor,
//                     borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                   ),
//                   child: Center(
//                     child: Text(
//                       'Pour quelqu\'un d\'autre',
//                       style: textMedium.copyWith(
//                         color: Colors.white,
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//         const SizedBox(height: Dimensions.paddingSizeSmall),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             TextButton(
//               onPressed: () {
//                 // OPTION 3: Ne plus afficher ce message (préférence permanente)
//                 print('🚫 Option "Ne plus me demander" sélectionnée');
                
//                 locationController.setDontAskAgain(true);
//                 setState(() {});
                
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(
//                     content: Text('Vous ne serez plus averti'),
//                     duration: const Duration(seconds: 2),
//                     backgroundColor: Colors.grey,
//                   ),
//                 );
//               },
//               child: Text(
//                 'Ne plus me demander',
//                 style: textRegular.copyWith(
//                   fontSize: Dimensions.fontSizeExtraSmall,
//                   color: Colors.grey[500],
//                 ),
//               ),
//             ),
//             const SizedBox(width: Dimensions.paddingSizeSmall),
//             TextButton(
//               onPressed: () {
//                 // OPTION 4: Fermer simplement le prompt (pour cette fois seulement)
//                 print('❌ Option "Fermer" sélectionnée');
                
//                 // Mais on le marque comme affiché pour ne pas réafficher dans cette session
//                 locationController.resetRideForOtherPromptFlag();
//                 setState(() {});
//               },
//               child: Text(
//                 'Fermer',
//                 style: textRegular.copyWith(
//                   fontSize: Dimensions.fontSizeExtraSmall,
//                   color: Colors.grey[500],
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ],
//     ),
//   );
// }



//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       top: false,
//       child: Scaffold(
//         resizeToAvoidBottomInset: false,
//         body: GetBuilder<RideController>(builder: (rideController) {
//                   return BodyWidget(
//             appBar: AppBarWidget(
//               title: rideController.rideType == RideType.scheduleRide
//                   ? 'schedule_trip_setup'.tr
//                   : 'trip_setup'.tr,
//               centerTitle: true,
//               onBackPressed: () {
//                 if (Navigator.canPop(context)) {
//                   Get.back();
//                 } else {
//                   Get.offAll(() => const DashboardScreen());
//                 }
//               },
//             ),
//             body: GetBuilder<LocationController>(
//                 builder: (locationController) {
//                   // Vérifier si tous les trajets sont renseignés
//                   bool hasValidRoute = locationController.fromAddress != null && 
//                                       locationController.toAddress != null;
                  
//                   // Vérifier si le point de départ a été modifié par rapport à la position initiale
//                   bool isPickupModifiedFromInitial = locationController.isPickupModifiedFromInitial();
                  
//                   // N'afficher l'option que si :
//                   // 1. L'utilisateur a un trajet valide (départ ET destination)
//                   // 2. L'utilisateur a modifié le point de départ par rapport à sa position initiale
//                   // 3. Ce n'est pas déjà activé pour quelqu'un d'autre
//                   // 4. Le prompt n'a pas déjà été affiché dans cette session
//                   bool showRideForOtherPrompt = hasValidRoute && 
//                                                 isPickupModifiedFromInitial && 
//                                                 !locationController.isRideForOther &&
//                                                 !locationController.hasShownRideForOtherPrompt;

//                   return Stack(clipBehavior: Clip.none, children: [
//                     Padding(
//                       padding: const EdgeInsets.fromLTRB(
//                         Dimensions.paddingSizeDefault,
//                         Dimensions.paddingSizeDefault,
//                         Dimensions.paddingSizeDefault,
//                         Dimensions.paddingSizeSmall,
//                       ),
//                       child: SingleChildScrollView(
//                         controller: scrollController,
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           mainAxisSize: MainAxisSize.min,
//                           children: [
//                            // RideCategoryWidget(),
//                             const SizedBox(height: Dimensions.paddingSizeSmall),
                            
//                             // Prompt : Commander pour quelqu'un d'autre (si conditions remplies)
//                             if (showRideForOtherPrompt)
//                               _buildRideForOtherPrompt(locationController),
                            
//                             if (showRideForOtherPrompt) 
//                               const SizedBox(height: Dimensions.paddingSizeSmall),
                            
//                             // Si déjà activé pour quelqu'un d'autre, afficher le widget complet
//                             if (locationController.isRideForOther)
//                               _RideForOtherWidget(),
                            
//                             if (locationController.isRideForOther) 
//                               const SizedBox(height: Dimensions.paddingSizeSmall),
                            
//                         //    PickupTimeDateWidget(),
//                             const SizedBox(height: Dimensions.paddingSizeSmall),
                            
//                             // Bouton pour réactiver le suivi automatique (si modifié manuellement)
//                             _buildAutoTrackingButton(locationController),
                            
//                             Row(
//                               children: [
//                                 Text('set_your_location'.tr, style: textSemiBold),
//                                 _buildEnhancedLocationIndicator(locationController),
//                               ],
//                             ),
//                             const SizedBox(height: Dimensions.paddingSizeSmall),
//                             Container(
//                               decoration: BoxDecoration(
//                                 color: Theme.of(context)
//                                     .hintColor
//                                     .withValues(alpha: 0.1),
//                                 borderRadius: BorderRadius.circular(
//                                     Dimensions.paddingSizeSmall),
//                               ),
//                               child: Column(children: [
//                                 Row(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     _LocationFromToWidget(),
//                                     Expanded(
//                                       child: Padding(
//                                         padding: const EdgeInsets.only(
//                                           top: Dimensions.paddingSizeDefault,
//                                           right: Dimensions.paddingSizeDefault,
//                                           bottom: Dimensions.paddingSizeDefault,
//                                         ),
//                                         child: Column(
//                                           crossAxisAlignment:
//                                           CrossAxisAlignment.start,
//                                           children: [
//                                             // Point de départ
//                                             PickLocationWidget(
//                                               locationType: LocationType.from,
//                                               rideDetails: rideController.rideDetails,
//                                               focusNode: pickLocationFocus,
//                                               textEditingController:
//                                               locationController
//                                                   .pickupLocationController,
//                                               isShowCrossButton: false,
//                                               textFieldHint: 'pick_location'.tr,
//                                               locationIconTap: () {
//                                                 RouteHelper.goPageAndHideTextField(
//                                                   context,
//                                                   PickMapScreen(
//                                                     type: LocationType.from,
//                                                     address:
//                                                     locationController.fromAddress,
//                                                   ),
//                                                 );
//                                               },
//                                               textFieldTap: () {
//                                                 setScrollAndDialogPosition(
//                                                     LocationType.from,
//                                                     locationController);
//                                               },
//                                               onSuggestionSelected: () {
//                                                 _pickupSelected = true;
//                                                 _checkAndTriggerSearch();
//                                               },
//                                             ),
//                                             Padding(
//                                               padding: const EdgeInsets.symmetric(
//                                                 vertical: 2.0,
//                                               ),
//                                               child: Text('to'.tr,
//                                                   style: textRegular.copyWith(
//                                                       color: Theme.of(context)
//                                                           .textTheme
//                                                           .bodyMedium
//                                                           ?.color)),
//                                             ),

//                                             // Section des arrêts
//                                             _buildStopsSection(
//                                                 locationController, rideController),

//                                             // Destination et bouton d'ajout
//                                             Row(children: [
//                                               Expanded(
//                                                 child: PickLocationWidget(
//                                                   locationType: LocationType.to,
//                                                   textFieldHint: 'destination'.tr,
//                                                   rideDetails:
//                                                   rideController.rideDetails,
//                                                   focusNode:
//                                                   destinationLocationFocus,
//                                                   textEditingController:
//                                                   locationController
//                                                       .destinationLocationController,
//                                                   isShowCrossButton: false,
//                                                   locationIconTap: () {
//                                                     RouteHelper
//                                                         .goPageAndHideTextField(
//                                                       context,
//                                                       PickMapScreen(
//                                                         type: LocationType.to,
//                                                         address: locationController
//                                                             .toAddress,
//                                                       ),
//                                                     );
//                                                   },
//                                                   textFieldTap: () {
//                                                     setScrollAndDialogPosition(
//                                                         LocationType.to,
//                                                         locationController);
//                                                   },
//                                                   onSuggestionSelected: () {
//                                                     _destinationSelected = true;
//                                                     _checkAndTriggerSearch();
//                                                   },
//                                                 ),
//                                               ),
//                                               SizedBox(width: Dimensions.paddingSizeSmall),
//                                               _buildAddStopButton(locationController),
//                                             ]),
//                                           ],
//                                         ),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                                 Padding(
//                                   padding: const EdgeInsets.fromLTRB(
//                                     Dimensions.paddingSizeExtraLarge,
//                                     0,
//                                     Dimensions.paddingSizeExtraLarge,
//                                     Dimensions.paddingSizeSmall,
//                                   ),
//                                   child: Row(
//                                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                                     children: [
//                                       Expanded(
//                                         child: Text(
//                                           'you_can_add_multiple_route_to'.tr,
//                                           style: textRegular.copyWith(
//                                             fontSize: Dimensions.fontSizeSmall,
//                                             color: Theme.of(context)
//                                                 .textTheme
//                                                 .bodyMedium!
//                                                 .color!
//                                                 .withValues(alpha: 0.7),
//                                           ),
//                                         ),
//                                       ),
//                                       if (_hasStops(locationController))
//                                         _buildRemoveAllStopsButton(locationController),
//                                     ],
//                                   ),
//                                 ),
//                               ]),
//                             ),
//                             if (rideController.rideType == RideType.scheduleRide)
//                               ReservationNoteWidget(globalKey: _key),
//                             SizedBox(height: bottomWhiteSpace)
//                           ],
//                         ),
//                       ),
//                     ),

//                     // Boîte de dialogue d'autocomplete
//                     if (locationController.resultShow)
//                       Positioned(
//                         top: 0,
//                         left: 0,
//                         right: 0,
//                         child: InkWell(
//                           onTap: () =>
//                               locationController.setSearchResultShowHide(show: false),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: Get.isDarkMode
//                                   ? Theme.of(context).canvasColor
//                                   : Theme.of(context).cardColor,
//                               borderRadius: BorderRadius.circular(
//                                   Dimensions.paddingSizeDefault),
//                             ),
//                             margin: EdgeInsets.fromLTRB(30, dialogTopPosition, 30, 0),
//                             child: ListView.builder(
//                               itemCount: locationController
//                                   .predictionList?.data?.suggestions?.length ??
//                                   0,
//                               shrinkWrap: true,
//                               padding: EdgeInsets.zero,
//                               physics: const NeverScrollableScrollPhysics(),
//                               itemBuilder: (context, index) {
//                                 return InkWell(
//                                   onTap: () {
//                                     Get.find<LocationController>().setLocation(
//                                       fromSearch: true,
//                                       locationController.predictionList?.data
//                                           ?.suggestions?[index]
//                                           .placePrediction
//                                           ?.placeId ??
//                                           '',
//                                       locationController.predictionList?.data
//                                           ?.suggestions?[index]
//                                           .placePrediction
//                                           ?.text
//                                           ?.text ??
//                                           '',
//                                       null,
//                                       type: locationController.locationType,
//                                     ).then((_) {
//                                       // Après avoir défini l'adresse, marquer comme sélectionné
//                                       if (locationController.locationType == LocationType.from) {
//                                         _pickupSelected = true;
//                                       } else if (locationController.locationType == LocationType.to) {
//                                         _destinationSelected = true;
//                                       }
//                                       _checkAndTriggerSearch();
//                                     });
//                                   },
//                                   child: Padding(
//                                     padding: const EdgeInsets.symmetric(
//                                       vertical: Dimensions.paddingSizeDefault,
//                                       horizontal: Dimensions.paddingSizeSmall,
//                                     ),
//                                     child: Row(children: [
//                                       const Icon(Icons.location_on),
//                                       Expanded(
//                                         child: Text(
//                                           locationController.predictionList?.data
//                                               ?.suggestions?[index]
//                                               .placePrediction
//                                               ?.text
//                                               ?.text ??
//                                               '',
//                                           maxLines: 1,
//                                           overflow: TextOverflow.ellipsis,
//                                           style: Theme.of(context)
//                                               .textTheme
//                                               .displayMedium!
//                                               .copyWith(
//                                             color: Theme.of(context)
//                                                 .textTheme
//                                                 .bodyLarge!
//                                                 .color,
//                                             fontSize: Dimensions.fontSizeDefault,
//                                           ),
//                                         ),
//                                       ),
//                                     ]),
//                                   ),
//                                 );
//                               },
//                             ),
//                           ),
//                         ),
//                       ),
//                   ]);
//                 }),
//           );
//         }),
//         bottomNavigationBar: ProcessButtonWidget(
//           pickLocationFocus: pickLocationFocus,
//           destinationLocationFocus: destinationLocationFocus,
        
//         ),
//       ),
//     );
//   }

//   // Vérifie si on peut ajouter plus d'arrêts
//   bool _canAddMoreStops(LocationController locationController) {
//     return Get.find<ConfigController>().config!.addIntermediatePoint! &&
//         !locationController.extraThreeRoute;
//   }

//   // Vérifie s'il y a des arrêts
//   bool _hasStops(LocationController locationController) {
//     return locationController.extraOneRoute ||
//         locationController.extraTwoRoute ||
//         locationController.extraThreeRoute;
//   }

//   // Compte le nombre d'arrêts actuels
//   int _getCurrentStopsCount(LocationController locationController) {
//     int count = 0;
//     if (locationController.extraOneRoute) count++;
//     if (locationController.extraTwoRoute) count++;
//     if (locationController.extraThreeRoute) count++;
//     return count;
//   }

//   // Widget du bouton "Ajouter un arrêt"
//   Widget _buildAddStopButton(LocationController locationController) {
//     final currentStops = _getCurrentStopsCount(locationController);
//     final canAddMore = _canAddMoreStops(locationController);

//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.end,
//       children: [
//         Container(
//           width: 70,
//           height: 3,
//           margin: const EdgeInsets.only(bottom: 2),
//           decoration: BoxDecoration(
//             color: Colors.grey[300],
//             borderRadius: BorderRadius.circular(1.5),
//           ),
//           child: Row(
//             children: [
//               for (int i = 0; i < 3; i++)
//                 Expanded(
//                   child: Container(
//                     margin: const EdgeInsets.symmetric(horizontal: 0.5),
//                     decoration: BoxDecoration(
//                       color: i < currentStops ? Theme.of(context).primaryColor : Colors.grey[300],
//                       borderRadius: BorderRadius.circular(1),
//                     ),
//                   ),
//                 ),
//             ],
//           ),
//         ),
//         InkWell(
//           onTap: canAddMore ? () {
//             _addNewRoute(locationController);
//           } : null,
//           child: Container(
//             height: 30,
//             width: 70,
//             decoration: BoxDecoration(
//               color: canAddMore ? Theme.of(context).primaryColor : Colors.grey[400],
//               borderRadius: BorderRadius.circular(
//                 Dimensions.paddingSizeExtraSmall,
//               ),
//             ),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Icon(Icons.add,
//                     color: canAddMore ? Colors.white : Colors.grey[200],
//                     size: 14
//                 ),
//                 const SizedBox(width: 2),
//                 Text(
//                   'Arrêt',
//                   style: TextStyle(
//                     color: canAddMore ? Colors.white : Colors.grey[200],
//                     fontSize: 10,
//                   ),
//                 ),
//                 Container(
//                   margin: const EdgeInsets.only(left: 2),
//                   padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
//                   decoration: BoxDecoration(
//                     color: Colors.white.withOpacity(0.3),
//                     borderRadius: BorderRadius.circular(6),
//                   ),
//                   child: Text(
//                     '$currentStops/3',
//                     style: TextStyle(
//                       color: canAddMore ? Colors.white : Colors.grey[200],
//                       fontSize: 8,
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ],
//     );
//   }

//   // Widget du bouton "Supprimer tous les arrêts"
//   Widget _buildRemoveAllStopsButton(LocationController locationController) {
//     return InkWell(
//       onTap: () {
//         _showRemoveAllDialog(context, locationController);
//       },
//       child: Container(
//         padding: const EdgeInsets.symmetric(
//           horizontal: Dimensions.paddingSizeSmall,
//           vertical: Dimensions.paddingSizeExtraSmall,
//         ),
//         decoration: BoxDecoration(
//           color: Colors.red.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//           border: Border.all(color: Colors.red.withOpacity(0.3)),
//         ),
//         child: Row(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Icon(
//               Icons.delete_forever,
//               color: Colors.red,
//               size: 14,
//             ),
//             const SizedBox(width: Dimensions.paddingSizeExtraSmall),
//             Text(
//               'supprimer_tout'.tr,
//               style: textMedium.copyWith(
//                 fontSize: Dimensions.fontSizeExtraSmall,
//                 color: Colors.red,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   // Dialogue de confirmation suppression totale
//   void _showRemoveAllDialog(BuildContext context, LocationController locationController) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('supprimer_tous_les_arrêts'.tr),
//           content: Text('voulez_vous_supprimer_tous_les_arrêts_intermédiaires'.tr),
//           actions: [
//             TextButton(
//               onPressed: () => Get.back(),
//               child: Text('annuler'.tr),
//             ),
//             TextButton(
//               onPressed: () {
//                 _removeAllStops(locationController);
//                 Get.back();
//               },
//               child: Text('supprimer'.tr, style: TextStyle(color: Colors.red)),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // Section des arrêts
//   Widget _buildStopsSection(
//       LocationController locationController, RideController rideController) {
//     final routes = _getRoutesList(locationController);
//     if (routes.isEmpty) return const SizedBox.shrink();

//     return Column(
//       mainAxisSize: MainAxisSize.min,
//       children: [
//         for (int i = 0; i < routes.length; i++)
//           Padding(
//             padding: EdgeInsets.only(
//               bottom: i < routes.length - 1 ? 0 : 0,
//             ),
//             child: _buildStopItem(
//               routes[i],
//               locationController,
//               rideController,
//               i,
//               routes.length,
//             ),
//           ),
//       ],
//     );
//   }

//   // Widget d'un arrêt avec autocomplete fonctionnel
//   Widget _buildStopItem(
//       Map<String, dynamic> route,
//       LocationController locationController,
//       RideController rideController,
//       int index,
//       int totalStops,
//       ) {
//     final type = route['type'];
//     final hint = route['hint'];
//     final controller = route['controller'];
//     final address = route['address'];

//     return Container(
//       margin: const EdgeInsets.only(top: 0),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//       ),
//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           // Contrôles à gauche
//           Container(
//             width: 72,
//             padding: const EdgeInsets.only(top: 8),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 if (index > 0)
//                   InkWell(
//                     onTap: () {
//                       _moveStopUp(index, locationController);
//                     },
//                     child: Container(
//                       padding: const EdgeInsets.all(4),
//                       decoration: BoxDecoration(
//                         color: Theme.of(context).primaryColor.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(4),
//                       ),
//                       child: Icon(
//                         Icons.arrow_upward,
//                         size: 16,
//                         color: Theme.of(context).primaryColor,
//                       ),
//                     ),
//                   )
//                 else
//                   const SizedBox(width: 24),

//                 InkWell(
//                   onTap: () {
//                     _swapWithDestination(type, locationController);
//                   },
//                   child: Container(
//                     padding: const EdgeInsets.all(4),
//                     decoration: BoxDecoration(
//                       color: Theme.of(context).primaryColor.withOpacity(0.1),
//                       borderRadius: BorderRadius.circular(4),
//                     ),
//                     child: Icon(
//                       Icons.swap_vert,
//                       size: 16,
//                       color: Theme.of(context).primaryColor,
//                     ),
//                   ),
//                 ),

//                 if (index < totalStops - 1)
//                   InkWell(
//                     onTap: () {
//                       _moveStopDown(index, locationController);
//                     },
//                     child: Container(
//                       padding: const EdgeInsets.all(4),
//                       decoration: BoxDecoration(
//                         color: Theme.of(context).primaryColor.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(4),
//                       ),
//                       child: Icon(
//                         Icons.arrow_downward,
//                         size: 16,
//                         color: Theme.of(context).primaryColor,
//                       ),
//                     ),
//                   )
//                 else
//                   const SizedBox(width: 24),
//               ],
//             ),
//           ),

//           // Contenu de l'arrêt avec PickLocationWidget corrigé
//           Expanded(
//             child: Container(
//               decoration: BoxDecoration(
//                 borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//               ),
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: PickLocationWidget(
//                       locationType: type,
//                       textFieldHint: hint,
//                       rideDetails: rideController.rideDetails,
//                       focusNode: null,
//                       textEditingController: controller,
//                       isShowCrossButton: true,
//                       locationIconTap: () {
//                         RouteHelper.goPageAndHideTextField(
//                           context,
//                           PickMapScreen(
//                             type: type,
//                             address: address,
//                           ),
//                         );
//                       },
//                       textFieldTap: () {
//                         // IMPORTANT: Déclenche l'autocomplete
//                         setScrollAndDialogPosition(type, locationController);
//                       },
//                       onSuggestionSelected: () {
//                         // Marquer comme sélectionné selon le type
//                         if (type == LocationType.extraOne ||
//                             type == LocationType.extraTwo ||
//                             type == LocationType.extraThree) {
//                           // Pour les arrêts, on ne déclenche pas la recherche
//                         }
//                       },
//                     ),
//                   ),
//                   IconButton(
//                     onPressed: () {
//                       _showDeleteDialog(type, locationController);
//                     },
//                     icon: Icon(
//                       Icons.delete,
//                       color: Colors.red,
//                       size: 18,
//                     ),
//                     padding: EdgeInsets.zero,
//                     constraints: const BoxConstraints(
//                       minWidth: 36,
//                       minHeight: 36,
//                     ),
//                     tooltip: 'Supprimer cet arrêt',
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   // Dialogue de confirmation suppression d'un arrêt
//   void _showDeleteDialog(LocationType type, LocationController locationController) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('supprimer_l_arrêt'.tr),
//           content: Text('voulez_vous_supprimer_cet_arrêt'.tr),
//           actions: [
//             TextButton(
//               onPressed: () => Get.back(),
//               child: Text('annuler'.tr),
//             ),
//             TextButton(
//               onPressed: () {
//                 Get.back();
//                 _removeStop(type, locationController);
//               },
//               child: Text('supprimer'.tr, style: TextStyle(color: Colors.red)),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   // Obtenir la liste des arrêts
//   List<Map<String, dynamic>> _getRoutesList(LocationController locationController) {
//     final List<Map<String, dynamic>> routes = [];

//     if (locationController.extraOneRoute) {
//       routes.add({
//         'type': LocationType.extraOne,
//         'hint': 'extra_route_one'.tr,
//         'controller': locationController.extraRouteOneController,
//         'address': locationController.extraRouteAddress,
//       });
//     }

//     if (locationController.extraTwoRoute) {
//       routes.add({
//         'type': LocationType.extraTwo,
//         'hint': 'extra_route_two'.tr,
//         'controller': locationController.extraRouteTwoController,
//         'address': locationController.extraRouteTwoAddress,
//       });
//     }

//     if (locationController.extraThreeRoute) {
//       routes.add({
//         'type': LocationType.extraThree,
//         'hint': 'extra_route_three'.tr,
//         'controller': locationController.extraRouteThreeController,
//         'address': locationController.extraRouteThreeAddress,
//       });
//     }

//     return routes;
//   }

//   // Ajouter un nouvel arrêt
//   void _addNewRoute(LocationController locationController) {
//     if (!locationController.extraOneRoute) {
//       locationController.extraOneRoute = true;
//     } else if (!locationController.extraTwoRoute) {
//       locationController.extraTwoRoute = true;
//     } else if (!locationController.extraThreeRoute) {
//       locationController.extraThreeRoute = true;
//     }
//     locationController.update();
//     setState(() {});
//   }

//   // Déplacer un arrêt vers le haut
//   void _moveStopUp(int index, LocationController locationController) {
//     if (index <= 0) return;

//     final routes = _getRoutesList(locationController);
//     if (routes.length < 2) return;

//     final temp = routes[index];
//     routes[index] = routes[index - 1];
//     routes[index - 1] = temp;

//     _updateControllersWithNewOrder(routes, locationController);
//   }

//   // Déplacer un arrêt vers le bas
//   void _moveStopDown(int index, LocationController locationController) {
//     final routes = _getRoutesList(locationController);
//     if (index >= routes.length - 1) return;

//     final temp = routes[index];
//     routes[index] = routes[index + 1];
//     routes[index + 1] = temp;

//     _updateControllersWithNewOrder(routes, locationController);
//   }

//   // Supprimer un arrêt
//   void _removeStop(LocationType type, LocationController locationController) {
//     switch (type) {
//       case LocationType.extraOne:
//         locationController.extraOneRoute = false;
//         locationController.extraRouteOneController.clear();
//         locationController.extraRouteAddress = null;
//         break;
//       case LocationType.extraTwo:
//         locationController.extraTwoRoute = false;
//         locationController.extraRouteTwoController.clear();
//         locationController.extraRouteTwoAddress = null;
//         break;
//       case LocationType.extraThree:
//         locationController.extraThreeRoute = false;
//         locationController.extraRouteThreeController.clear();
//         locationController.extraRouteThreeAddress = null;
//         break;
//       default:
//         return;
//     }

//     locationController.update();
//     Get.find<RideController>().update();
//     setState(() {});
//   }

//   // Mettre à jour les contrôleurs avec le nouvel ordre
//   void _updateControllersWithNewOrder(
//       List<Map<String, dynamic>> routes, LocationController locationController) {
//     locationController.extraOneRoute = false;
//     locationController.extraTwoRoute = false;
//     locationController.extraThreeRoute = false;

//     locationController.extraRouteOneController.clear();
//     locationController.extraRouteTwoController.clear();
//     locationController.extraRouteThreeController.clear();

//     locationController.extraRouteAddress = null;
//     locationController.extraRouteTwoAddress = null;
//     locationController.extraRouteThreeAddress = null;

//     for (int i = 0; i < routes.length; i++) {
//       final route = routes[i];
//       final type = route['type'];
//       final controller = route['controller'] as TextEditingController;
//       final address = route['address'] as Address?;

//       String currentText = controller.text;

//       if (i == 0) {
//         locationController.extraOneRoute = true;
//         locationController.extraRouteOneController.text = currentText;
//         locationController.extraRouteAddress = address;
//       } else if (i == 1) {
//         locationController.extraTwoRoute = true;
//         locationController.extraRouteTwoController.text = currentText;
//         locationController.extraRouteTwoAddress = address;
//       } else if (i == 2) {
//         locationController.extraThreeRoute = true;
//         locationController.extraRouteThreeController.text = currentText;
//         locationController.extraRouteThreeAddress = address;
//       }
//     }

//     locationController.update();
//     Get.find<RideController>().update();
//     setState(() {});
//   }

//   // Échanger un arrêt avec la destination
//   void _swapWithDestination(LocationType routeType, LocationController locationController) {
//     final tempDestText = locationController.destinationLocationController.text;
//     final tempDestAddress = locationController.toAddress;

//     switch (routeType) {
//       case LocationType.extraOne:
//         final tempRouteText = locationController.extraRouteOneController.text;
//         final tempRouteAddress = locationController.extraRouteAddress;
//         locationController.extraRouteOneController.text = tempDestText;
//         locationController.extraRouteAddress = tempDestAddress;
//         locationController.destinationLocationController.text = tempRouteText;
//         locationController.toAddress = tempRouteAddress;
//         break;
//       case LocationType.extraTwo:
//         final tempRouteText = locationController.extraRouteTwoController.text;
//         final tempRouteAddress = locationController.extraRouteTwoAddress;
//         locationController.extraRouteTwoController.text = tempDestText;
//         locationController.extraRouteTwoAddress = tempDestAddress;
//         locationController.destinationLocationController.text = tempRouteText;
//         locationController.toAddress = tempRouteAddress;
//         break;
//       case LocationType.extraThree:
//         final tempRouteText = locationController.extraRouteThreeController.text;
//         final tempRouteAddress = locationController.extraRouteThreeAddress;
//         locationController.extraRouteThreeController.text = tempDestText;
//         locationController.extraRouteThreeAddress = tempDestAddress;
//         locationController.destinationLocationController.text = tempRouteText;
//         locationController.toAddress = tempRouteAddress;
//         break;
//       default:
//         return;
//     }

//     locationController.update();
//     Get.find<RideController>().update();
//     setState(() {});
//   }

//   // Supprimer tous les arrêts
//   void _removeAllStops(LocationController locationController) {
//     locationController.extraRouteOneController.clear();
//     locationController.extraRouteTwoController.clear();
//     locationController.extraRouteThreeController.clear();

//     locationController.extraRouteAddress = null;
//     locationController.extraRouteTwoAddress = null;
//     locationController.extraRouteThreeAddress = null;

//     locationController.extraOneRoute = false;
//     locationController.extraTwoRoute = false;
//     locationController.extraThreeRoute = false;

//     locationController.update();
//     Get.find<RideController>().update();
//     setState(() {});
//   }

//   // Méthode corrigée pour positionner la boîte de dialogue d'autocomplete
//   void setScrollAndDialogPosition(
//       LocationType locationType, LocationController locationController) {

//     // Ajuster le scroll comme dans la version originale
//     scrollController.jumpTo(MediaQuery.of(context).size.height + Get.height * 0.3);

//     // Calculer l'espace blanc en bas
//     bottomWhiteSpace = Get.find<RideController>().rideType == RideType.scheduleRide
//         ? (Get.height * 0.4 - (_key.currentContext?.size?.height ?? 0))
//         : Get.height * 0.4;

//     // Positionner la boîte de dialogue selon le type de champ (comme dans l'original)
//     if (locationType == LocationType.from) {
//       dialogTopPosition = Get.height * 0.2;
//     } else if (locationType == LocationType.extraOne) {
//       dialogTopPosition = locationController.extraTwoRoute ? Get.height * 0.18 : Get.height * 0.23;
//     } else if (locationType == LocationType.extraTwo) {
//       dialogTopPosition = Get.height * 0.23;
//     } else if (locationType == LocationType.extraThree) {
//       dialogTopPosition = Get.height * 0.23;
//     } else if (locationType == LocationType.to) {
//       dialogTopPosition = Get.height * 0.28;
//     }

//     setState(() {});
//   }
// }

// class _LocationFromToWidget extends StatelessWidget {
//   const _LocationFromToWidget();

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(
//         Dimensions.paddingSizeSmall,
//         Dimensions.paddingSizeDefault,
//         0,
//         0,
//       ),
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           SizedBox(
//             width: Dimensions.iconSizeLarge,
//             child: Image.asset(
//               Images.currentLocation,
//               color: Theme.of(context).textTheme.bodyMedium!.color,
//             ),
//           ),
//           Container(
//             height: 40,
//             width: 10,
//             child: CustomDivider(
//               height: 4,
//               dashWidth: 0.8,
//               axis: Axis.vertical,
//               color: Theme.of(context)
//                   .textTheme
//                   .bodyMedium!
//                   .color!
//                   .withValues(alpha: 0.5),
//             ),
//           ),
//           SizedBox(
//             width: Dimensions.iconSizeMedium,
//             child: Transform(
//               alignment: Alignment.center,
//               transform: Get.find<LocalizationController>().isLtr
//                   ? Matrix4.rotationY(0)
//                   : Matrix4.rotationY(math.pi),
//               child: Image.asset(
//                 Images.activityDirection,
//                 color: Theme.of(context).textTheme.bodyMedium!.color,
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// // WIDGET : Commander pour un autre
// class _RideForOtherWidget extends StatefulWidget {
//   const _RideForOtherWidget();

//   @override
//   State<_RideForOtherWidget> createState() => _RideForOtherWidgetState();
// }

// class _RideForOtherWidgetState extends State<_RideForOtherWidget> {
//   final TextEditingController _phoneController = TextEditingController();
//   final FocusNode _phoneFocusNode = FocusNode();
//   bool _saveContact = false;

//   @override
//   void initState() {
//     super.initState();
//     // Initialiser avec les valeurs existantes si nécessaire
//     final locationController = Get.find<LocationController>();
//     if (locationController.isRideForOther) {
//       _phoneController.text = locationController.beneficiaryPhone;
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<LocationController>(
//       builder: (locationController) {
//         return Container(
//           margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
//           decoration: BoxDecoration(
//             color: Theme.of(context).cardColor,
//             borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
//             border: Border.all(
//               color: locationController.isRideForOther 
//                 ? Theme.of(context).primaryColor.withOpacity(0.5)
//                 : Colors.grey.withOpacity(0.2),
//               width: 1,
//             ),
//             boxShadow: [
//               BoxShadow(
//                 color: Colors.grey.withOpacity(0.05),
//                 blurRadius: 5,
//                 offset: const Offset(0, 2),
//               ),
//             ],
//           ),
//           child: Column(
//             children: [
//               // En-tête avec switch
//               Padding(
//                 padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
//                 child: Row(
//                   children: [
//                     Container(
//                       padding: const EdgeInsets.all(8),
//                       decoration: BoxDecoration(
//                         color: locationController.isRideForOther 
//                           ? Theme.of(context).primaryColor.withOpacity(0.1)
//                           : Colors.grey.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                       ),
//                       child: Icon(
//                         Icons.person_outline,
//                         color: locationController.isRideForOther 
//                           ? Theme.of(context).primaryColor
//                           : Colors.grey,
//                         size: 20,
//                       ),
//                     ),
//                     const SizedBox(width: Dimensions.paddingSizeSmall),
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             'Cette course est pour vous ou pour quelqu\'un d\'autre ?',
//                             style: textRegular.copyWith(
//                               fontSize: Dimensions.fontSizeSmall,
//                               color: Colors.grey[600],
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             locationController.isRideForOther 
//                               ? 'Pour quelqu\'un d\'autre' 
//                               : 'Pour moi-même',
//                             style: textSemiBold.copyWith(
//                               fontSize: Dimensions.fontSizeDefault,
//                               color: locationController.isRideForOther 
//                                 ? Theme.of(context).primaryColor
//                                 : null,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     Switch(
//                       value: locationController.isRideForOther,
//                       onChanged: (value) {
//                         _toggleRideForOther(locationController, value: value);
//                       },
//                       activeColor: Theme.of(context).primaryColor,
//                       materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
//                     ),
//                   ],
//                 ),
//               ),
              
//               // Champ de saisie du numéro si activé (pour quelqu'un d'autre)
//               if (locationController.isRideForOther) ...[
//                 Container(
//                   height: 1,
//                   color: Colors.grey.withOpacity(0.2),
//                   margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         'Numéro du destinataire',
//                         style: textMedium.copyWith(
//                           fontSize: Dimensions.fontSizeSmall,
//                         ),
//                       ),
//                       const SizedBox(height: Dimensions.paddingSizeExtraSmall),
//                       Row(
//                         children: [
//                           Expanded(
//                             child: TextFormField(
//                               controller: _phoneController,
//                               focusNode: _phoneFocusNode,
//                               keyboardType: TextInputType.phone,
//                               decoration: InputDecoration(
//                                 hintText: 'Ex: +225 07 89 45 12 34',
//                                 prefixIcon: Icon(
//                                   Icons.phone,
//                                   color: Theme.of(context).primaryColor,
//                                   size: 18,
//                                 ),
//                                 filled: true,
//                                 fillColor: Theme.of(context).hintColor.withOpacity(0.05),
//                                 border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                                   borderSide: BorderSide.none,
//                                 ),
//                                 contentPadding: const EdgeInsets.symmetric(
//                                   horizontal: Dimensions.paddingSizeDefault,
//                                   vertical: Dimensions.paddingSizeSmall,
//                                 ),
//                               ),
//                               onChanged: (value) {
//                                 locationController.setBeneficiaryPhone(value);
//                               },
//                             ),
//                           ),
//                           const SizedBox(width: Dimensions.paddingSizeSmall),
                          
//                           // Bouton pour choisir depuis les contacts
//                           InkWell(
//                             onTap: () async {
//                               _showContactsDialog(context, locationController);
//                             },
//                             child: Container(
//                               padding: const EdgeInsets.all(12),
//                               decoration: BoxDecoration(
//                                 color: Theme.of(context).primaryColor.withOpacity(0.1),
//                                 borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                               ),
//                               child: Icon(
//                                 Icons.contacts,
//                                 color: Theme.of(context).primaryColor,
//                                 size: 20,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
                
//                 // Option pour sauvegarder le contact
//                 Padding(
//                   padding: const EdgeInsets.only(
//                     left: Dimensions.paddingSizeDefault,
//                     right: Dimensions.paddingSizeDefault,
//                     bottom: Dimensions.paddingSizeDefault,
//                   ),
//                   child: Row(
//                     children: [
//                       SizedBox(
//                         width: 20,
//                         height: 20,
//                         child: Checkbox(
//                           value: _saveContact,
//                           onChanged: (value) {
//                             setState(() {
//                               _saveContact = value ?? false;
//                             });
//                           },
//                           activeColor: Theme.of(context).primaryColor,
//                           materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
//                           visualDensity: VisualDensity.compact,
//                         ),
//                       ),
//                       const SizedBox(width: Dimensions.paddingSizeExtraSmall),
//                       Expanded(
//                         child: Text(
//                           'Sauvegarder ce contact',
//                           style: textRegular.copyWith(
//                             fontSize: Dimensions.fontSizeSmall,
//                             color: Colors.grey[600],
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ],
//           ),
//         );
//       },
//     );
//   }
  
//   void _toggleRideForOther(LocationController locationController, {required bool value}) {
//     if (value) {
//       // Activer (pour quelqu'un d'autre)
//       locationController.setRideForOther(true);
//     } else {
//       // Désactiver (pour moi-même)
//       _showConfirmationDialog(context, locationController);
//     }
//   }
  
//   void _showConfirmationDialog(BuildContext context, LocationController locationController) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('Confirmation'),
//           content: Text('Voulez-vous vraiment commander pour vous-même ? Les informations du destinataire seront effacées.'),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: Text('Non'),
//             ),
//             TextButton(
//               onPressed: () {
//                 locationController.setRideForOther(false);
//                 _phoneController.clear();
//                 Navigator.pop(context);
//               },
//               child: Text('Oui', style: TextStyle(color: Colors.red)),
//             ),
//           ],
//         );
//       },
//     );
//   }
  
//   void _showContactsDialog(BuildContext context, LocationController locationController) {
//     // Liste de contacts simulée
//     final List<Map<String, String>> mockContacts = [
//       {'name': 'Marie Dupont', 'phone': '+225 07 89 45 12 34'},
//       {'name': 'Jean Kouassi', 'phone': '+225 05 67 89 01 23'},
//       {'name': 'Sophie Yao', 'phone': '+225 01 23 45 67 89'},
//       {'name': 'Marc Konan', 'phone': '+225 09 87 65 43 21'},
//       {'name': 'Aminata Diallo', 'phone': '+225 03 45 67 89 01'},
//     ];

//     showModalBottomSheet(
//       context: context,
//       isScrollControlled: true,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (BuildContext context) {
//         return Container(
//           padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
//           constraints: BoxConstraints(
//             maxHeight: MediaQuery.of(context).size.height * 0.7,
//           ),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Center(
//                 child: Container(
//                   width: 40,
//                   height: 4,
//                   decoration: BoxDecoration(
//                     color: Colors.grey[300],
//                     borderRadius: BorderRadius.circular(2),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: Dimensions.paddingSizeDefault),
//               Text(
//                 'Choisir un contact',
//                 style: textBold.copyWith(
//                   fontSize: Dimensions.fontSizeLarge,
//                 ),
//               ),
//               const SizedBox(height: Dimensions.paddingSizeDefault),
              
//               // Barre de recherche
//               TextField(
//                 decoration: InputDecoration(
//                   hintText: 'Rechercher un contact',
//                   prefixIcon: const Icon(Icons.search),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
//                     borderSide: BorderSide.none,
//                   ),
//                   filled: true,
//                   fillColor: Colors.grey[100],
//                   contentPadding: const EdgeInsets.symmetric(
//                     vertical: Dimensions.paddingSizeSmall,
//                   ),
//                 ),
//               ),
//               const SizedBox(height: Dimensions.paddingSizeDefault),
              
//               // Liste des contacts
//               Expanded(
//                 child: ListView.builder(
//                   itemCount: mockContacts.length,
//                   shrinkWrap: true,
//                   itemBuilder: (context, index) {
//                     final contact = mockContacts[index];
//                     return ListTile(
//                       leading: CircleAvatar(
//                         backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
//                         child: Text(
//                           contact['name']![0],
//                           style: TextStyle(
//                             color: Theme.of(context).primaryColor,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                       ),
//                       title: Text(
//                         contact['name']!,
//                         style: textMedium,
//                       ),
//                       subtitle: Text(
//                         contact['phone']!,
//                         style: textRegular.copyWith(
//                           fontSize: Dimensions.fontSizeSmall,
//                           color: Colors.grey[600],
//                         ),
//                       ),
//                       onTap: () {
//                         setState(() {
//                           _phoneController.text = contact['phone']!;
//                         });
//                         locationController.setBeneficiaryPhone(contact['phone']!);
//                         Navigator.pop(context);
//                       },
//                     );
//                   },
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
  
//   @override
//   void dispose() {
//     _phoneController.dispose();
//     _phoneFocusNode.dispose();
//     super.dispose();
//   }
// }




import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ride_sharing_user_app/features/dashboard/screens/dashboard_screen.dart';
import 'package:ride_sharing_user_app/features/parcel/controllers/parcel_controller.dart';
import 'package:ride_sharing_user_app/features/ride/widgets/ride_category.dart';
import 'package:ride_sharing_user_app/features/set_destination/widget/pick_location_widget.dart';
import 'package:ride_sharing_user_app/features/set_destination/widget/pickup_time_date_widget.dart';
import 'package:ride_sharing_user_app/features/set_destination/widget/process_button_widget.dart';
import 'package:ride_sharing_user_app/features/set_destination/widget/reservation_note_widget.dart';
import 'package:ride_sharing_user_app/helper/route_helper.dart';
import 'package:ride_sharing_user_app/localization/localization_controller.dart';
import 'package:ride_sharing_user_app/util/dimensions.dart';
import 'package:ride_sharing_user_app/util/images.dart';
import 'package:ride_sharing_user_app/util/styles.dart';
import 'package:ride_sharing_user_app/features/address/domain/models/address_model.dart';
import 'package:ride_sharing_user_app/features/location/controllers/location_controller.dart';
import 'package:ride_sharing_user_app/features/location/view/pick_map_screen.dart';
import 'package:ride_sharing_user_app/features/map/controllers/map_controller.dart';
import 'package:ride_sharing_user_app/features/ride/controllers/ride_controller.dart';
import 'package:ride_sharing_user_app/features/splash/controllers/config_controller.dart';
import 'package:ride_sharing_user_app/common_widgets/app_bar_widget.dart';
import 'package:ride_sharing_user_app/common_widgets/body_widget.dart';
import 'package:ride_sharing_user_app/common_widgets/divider_widget.dart';
import 'package:ride_sharing_user_app/features/home/domain/models/categoty_model.dart';
import 'package:ride_sharing_user_app/features/home/controllers/category_controller.dart';
import 'package:ride_sharing_user_app/helper/display_helper.dart';
import 'package:ride_sharing_user_app/features/map/screens/map_screen.dart';

class SetDestinationScreen extends StatefulWidget {
  final Address? address;
  final String? searchText;
  final RideType rideType;

  const SetDestinationScreen({
    super.key,
    this.address,
    this.searchText,
    this.rideType = RideType.regularRide,
  });

  @override
  State<SetDestinationScreen> createState() => _SetDestinationScreenState();
}

class _SetDestinationScreenState extends State<SetDestinationScreen> {
  FocusNode pickLocationFocus = FocusNode();
  FocusNode destinationLocationFocus = FocusNode();
  ScrollController scrollController = ScrollController();
  double dialogTopPosition = 0;
  double bottomWhiteSpace = 0;
  var keyboardVisibilityController = KeyboardVisibilityController();
  late StreamSubscription<bool> keyboardSubscription;
  final GlobalKey _key = GlobalKey();
  bool _isInitialized = false;
  
  // Timer pour le debounce
  Timer? _debounceTimer;
  
  // Pour éviter les appels multiples
  bool _isSearchTriggered = false;
  
  // Pour suivre quand une adresse a été sélectionnée
  bool _pickupSelected = false;
  bool _destinationSelected = false;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeScreen();
      // Initialiser l'état "commander pour un autre" à false
      Get.find<LocationController>().resetRideForOther();
      Get.find<RideController>().clearBeneficiaryInfo();
      
      // DÉMARRER l'actualisation automatique de la position
      Get.find<LocationController>().startAutoLocationUpdate();
      
      // Définir la position actuelle comme point de départ
      _setInitialPickupLocation();
      
      // Écouter les changements dans les adresses (quand l'utilisateur sélectionne)
      _setupAddressListeners();
    });

    Get.find<RideController>().setRideType(widget.rideType);
    Get.find<LocationController>().initAddLocationData();
    Get.find<LocationController>().initTextControllers();
    Get.find<RideController>().clearExtraRoute();
    Get.find<MapController>().initializeData();
    Get.find<RideController>().initData();
    Get.find<ParcelController>().updatePaymentPerson(false, notify: false);

    if (widget.address != null) {
      Get.find<LocationController>().setDestination(widget.address);
    }
    if (widget.searchText != null) {
      Get.find<LocationController>().setDestination(Address(address: widget.searchText));
      Future.delayed(const Duration(seconds: 1)).then((_) {
        Get.find<LocationController>().searchLocation(
          Get.context!,
          widget.searchText ?? '',
          type: LocationType.to,
        );
      });
    }

    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
          if (!visible) {
            bottomWhiteSpace = 0;
          }
        });
  }

  // AJOUT : Écouter les changements d'adresses (quand l'utilisateur sélectionne une suggestion)
  void _setupAddressListeners() {
    final locationController = Get.find<LocationController>();
    
    // Utiliser un Worker avec une fonction qui retourne la valeur
    ever<Address?>(locationController.fromAddress as Rx<Address?>, (address) {
      if (address != null && address.address != null && address.address!.isNotEmpty) {
        print("📍 Adresse de départ sélectionnée: ${address.address}");
        _pickupSelected = true;
        _checkAndTriggerSearch();
      }
    });
    
    ever<Address?>(locationController.toAddress as Rx<Address?>, (address) {
      if (address != null && address.address != null && address.address!.isNotEmpty) {
        print("📍 Adresse de destination sélectionnée: ${address.address}");
        _destinationSelected = true;
        _checkAndTriggerSearch();
      }
    });
  }

  // AJOUT : Vérifier si les deux adresses sont sélectionnées et lancer la recherche
  void _checkAndTriggerSearch() {
    final locationController = Get.find<LocationController>();
    
    bool hasValidPickup = locationController.fromAddress != null && 
                         locationController.fromAddress!.address != null &&
                         locationController.fromAddress!.address!.isNotEmpty;
    
    bool hasValidDestination = locationController.toAddress != null && 
                              locationController.toAddress!.address != null &&
                              locationController.toAddress!.address!.isNotEmpty;
    
    print("🔍 Vérification recherche automatique:");
    print("  - Départ valide: $hasValidPickup (sélectionné: $_pickupSelected)");
    print("  - Destination valide: $hasValidDestination (sélectionnée: $_destinationSelected)");
    
    if (hasValidPickup && hasValidDestination && _pickupSelected && _destinationSelected) {
      // Annuler le timer précédent
      _debounceTimer?.cancel();
      
      // IMPORTANT: Vérifier si le point de départ est différent de la position actuelle
      // pour décider d'afficher ou non le prompt
      _checkAndShowRideForOtherPrompt();
      
      // Petit délai pour laisser le temps à l'UI de se mettre à jour
      _debounceTimer = Timer(const Duration(milliseconds: 300), () {
        _autoSearchRide();
      });
    }
  }

  // NOUVELLE MÉTHODE : Vérifier et afficher le prompt si nécessaire
  void _checkAndShowRideForOtherPrompt() {
    final locationController = Get.find<LocationController>();
    
    // Vérifier si le point de départ a été modifié par rapport à la position initiale
    bool isPickupModifiedFromInitial = locationController.isPickupModifiedFromInitial();
    
    // N'afficher l'option que si :
    // 1. L'utilisateur a modifié le point de départ par rapport à sa position initiale
    // 2. Ce n'est pas déjà activé pour quelqu'un d'autre
    // 3. Le prompt n'a pas déjà été affiché dans cette session
    // 4. L'utilisateur n'a pas coché "Ne plus me demander"
    bool shouldShowPrompt = isPickupModifiedFromInitial && 
                            !locationController.isRideForOther &&
                            !locationController.hasShownRideForOtherPrompt &&
                            !locationController.dontAskAgain;
    
    if (shouldShowPrompt) {
      print("👤 Condition remplie : affichage du prompt 'Commander pour quelqu'un d'autre'");
      print("  - Position modifiée: $isPickupModifiedFromInitial");
      print("  - isRideForOther: ${locationController.isRideForOther}");
      print("  - hasShownRideForOtherPrompt: ${locationController.hasShownRideForOtherPrompt}");
      print("  - dontAskAgain: ${locationController.dontAskAgain}");
      
      // Marquer comme affiché pour ne plus réafficher dans cette session
      locationController.hasShownRideForOtherPrompt == true;
      locationController.update();
      setState(() {}); // Forcer le rebuild pour afficher le prompt
    } else {
      print("👤 Condition NON remplie pour l'affichage du prompt:");
      print("  - Position modifiée: $isPickupModifiedFromInitial");
      print("  - isRideForOther: ${locationController.isRideForOther}");
      print("  - hasShownRideForOtherPrompt: ${locationController.hasShownRideForOtherPrompt}");
      print("  - dontAskAgain: ${locationController.dontAskAgain}");
    }
  }

  // Méthode pour lancer automatiquement la recherche
  Future<void> _autoSearchRide() async {
    // Éviter les appels multiples
    if (_isSearchTriggered) return;
    
    final locationController = Get.find<LocationController>();
    final rideController = Get.find<RideController>();
    final configController = Get.find<ConfigController>();
    
    // Vérifier la maintenance
    if (configController.config!.maintenanceMode != null &&
        configController.config!.maintenanceMode!.maintenanceStatus == 1 &&
        configController.config!.maintenanceMode!.selectedMaintenanceSystem!.userApp == 1) {
      showCustomSnackBar('maintenance_mode_on_for_ride'.tr, isError: true);
      return;
    }
    
    // Vérifier si une recherche est déjà en cours
    if (rideController.loading) return;
    
    // Marquer comme déclenché
    _isSearchTriggered = true;
    
    print("🚀 Lancement automatique de la recherche");
    print("📍 Départ: ${locationController.fromAddress?.address}");
    print("📍 Destination: ${locationController.toAddress?.address}");
    
    // Lancer la recherche
    var response = await rideController.getEstimatedFare(false);
    
    if (response.statusCode == 200) {
      print("✅ Recherche réussie, navigation vers MapScreen");
      // Navigation vers l'écran map
      Get.to(() => const MapScreen(
        fromScreen: MapScreenType.ride,
        isShowCurrentPosition: false,
      ));
      rideController.updateRideCurrentState(RideState.initial);
    } else {
      print("❌ Échec de la recherche");
      _isSearchTriggered = false; // Réinitialiser en cas d'échec
    }
  }

  // Méthode pour définir la position actuelle comme point de départ
  Future<void> _setInitialPickupLocation() async {
    try {
      final locationController = Get.find<LocationController>();
      
      // Vérifier si on a déjà une position
      if (locationController.position.latitude != 0 && 
          locationController.position.longitude != 0) {
        
        // Obtenir l'adresse à partir des coordonnées
        String address = await locationController.getAddressFromGeocode(
          LatLng(
            locationController.position.latitude,
            locationController.position.longitude
          )
        );
        
        // Créer l'adresse
        Address currentAddress = Address(
          latitude: locationController.position.latitude,
          longitude: locationController.position.longitude,
          address: address,
        );
        
        // Définir comme point de départ
        locationController.setPickUp(currentAddress);
        locationController.resetRideForOtherPromptFlag(); // Réinitialiser le flag
        locationController.update(); // Forcer la mise à jour
        _pickupSelected = true; // Marquer comme sélectionné
        print("📍 Position actuelle définie comme point de départ: $address");
      }
    } catch (e) {
      print("❌ Erreur lors de la définition de la position initiale: $e");
    }
  }

  void _initializeScreen() {
    if (_isInitialized) return;

    print("🚀 Initialisation de SetDestinationScreen");
    print("📋 Type de trajet: ${widget.rideType}");

    try {
      final rideController = Get.find<RideController>();
      final categoryController = Get.find<CategoryController>();

      if (widget.rideType == RideType.regularRide) {
        print("✅ Conservation de l'index actuel: ${rideController.rideCategoryIndex}");

        if (categoryController.categoryList != null &&
            categoryController.categoryList!.isNotEmpty) {

          if (rideController.rideCategoryIndex >= categoryController.categoryList!.length) {
            print("⚠️ Index invalide, réinitialisation à 0");
            rideController.setRideCategoryIndex(0);
          }
        }
      } else {
        print("📅 Trajet programmé, index actuel: ${rideController.rideCategoryIndex}");
      }

      if (categoryController.categoryList != null) {
        print("📋 Catégories disponibles:");
        for (int i = 0; i < categoryController.categoryList!.length; i++) {
          final cat = categoryController.categoryList![i];
          print("   Index $i: ${cat.name} - ID: ${cat.id} - Image: ${cat.image}");
        }
      }

      _isInitialized = true;
      rideController.update();

    } catch (e) {
      print("❌ Erreur: $e");
      Future.delayed(const Duration(milliseconds: 500), () {
        _initializeScreen();
      });
    }
  }

  @override
  void dispose() {
    // Annuler le timer
    _debounceTimer?.cancel();
    
    // ARRÊTER l'actualisation automatique
    Get.find<LocationController>().stopAutoLocationUpdate();
    keyboardSubscription.cancel();
    super.dispose();
  }

  // Widget indicateur de mise à jour de position amélioré
  Widget _buildEnhancedLocationIndicator(LocationController locationController) {
    bool isAutoTracking = !locationController.userModifiedManually;
    
    return Container(
      margin: const EdgeInsets.only(left: Dimensions.paddingSizeSmall),
      padding: const EdgeInsets.symmetric(
        horizontal: Dimensions.paddingSizeExtraSmall,
        vertical: 2,
      ),
      decoration: BoxDecoration(
        color: isAutoTracking 
          ? Colors.blue.withOpacity(0.1)
          : Colors.orange.withOpacity(0.1),
        borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (isAutoTracking) ...[
            SizedBox(
              width: 10,
              height: 10,
              child: CircularProgressIndicator(
                strokeWidth: 1.5,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
              ),
            ),
            const SizedBox(width: 4),
            Text(
              'Auto',
              style: textRegular.copyWith(
                fontSize: 8,
                color: Colors.blue,
              ),
            ),
          ] else ...[
            Icon(
              Icons.edit_location,
              color: Colors.orange,
              size: 10,
            ),
            const SizedBox(width: 4),
            Text(
              'Manuel',
              style: textRegular.copyWith(
                fontSize: 8,
                color: Colors.orange,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // Widget bouton pour réactiver le suivi automatique
  Widget _buildAutoTrackingButton(LocationController locationController) {
    // N'afficher le bouton que si l'utilisateur a modifié manuellement
    if (!locationController.userModifiedManually || locationController.isRideForOther) return const SizedBox.shrink();
    
    return Container(
      margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          InkWell(
            onTap: () async {
              // Réactiver le suivi automatique
              await locationController.resetToCurrentLocation();
              _pickupSelected = true; // Marquer comme sélectionné
              
              // Afficher un message de confirmation
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Position réinitialisée à votre position actuelle'),
                  duration: const Duration(seconds: 2),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: Dimensions.paddingSizeDefault,
                vertical: Dimensions.paddingSizeExtraSmall,
              ),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                border: Border.all(color: Colors.blue.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.my_location,
                    color: Colors.blue,
                    size: 16,
                  ),
                  const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                  Text(
                    'Utiliser ma position actuelle',
                    style: textMedium.copyWith(
                      fontSize: Dimensions.fontSizeSmall,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget pour demander si l'utilisateur veut commander pour quelqu'un d'autre
  Widget _buildRideForOtherPrompt(LocationController locationController) {
    return Container(
      margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
      padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor.withOpacity(0.05),
        borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
        border: Border.all(
          color: Theme.of(context).primaryColor.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                ),
                child: Icon(
                  Icons.help_outline,
                  color: Theme.of(context).primaryColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              Expanded(
                child: Text(
                  'Cette course est pour vous ?',
                  style: textSemiBold.copyWith(
                    fontSize: Dimensions.fontSizeDefault,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimensions.paddingSizeDefault),
          Text(
            'Vous avez modifié le point de départ à plus de 100 mètres de votre position actuelle. Souhaitez-vous commander pour quelqu\'un d\'autre ?',
            style: textRegular.copyWith(
              fontSize: Dimensions.fontSizeSmall,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: Dimensions.paddingSizeDefault),
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () {
                    // OPTION 1: L'utilisateur veut commander pour lui-même
                    print('👤 Option "Pour moi" sélectionnée');
                    
                    // Marquer comme affiché pour ne plus réafficher dans cette session
                    locationController.hasShownRideForOtherPrompt == true;
                    
                    // Forcer une mise à jour pour fermer le prompt
                    setState(() {});
                    
                    // Afficher un petit message de confirmation
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Course pour vous-même'),
                        duration: const Duration(seconds: 1),
                        backgroundColor: Colors.green,
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: Dimensions.paddingSizeSmall,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                    ),
                    child: Center(
                      child: Text(
                        'Pour moi',
                        style: textMedium.copyWith(
                          color: Colors.grey[700],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              Expanded(
                child: InkWell(
                  onTap: () {
                    // OPTION 2: L'utilisateur veut commander pour quelqu'un d'autre
                    print('👥 Option "Pour quelqu\'un d\'autre" sélectionnée');
                    
                    // Activer le mode "pour quelqu'un d'autre"
                    locationController.setRideForOther(true);
                    
                    // Forcer une mise à jour
                    setState(() {});
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: Dimensions.paddingSizeSmall,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                    ),
                    child: Center(
                      child: Text(
                        'Pour quelqu\'un d\'autre',
                        style: textMedium.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: Dimensions.paddingSizeSmall),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextButton(
                onPressed: () {
                  // OPTION 3: Ne plus afficher ce message (préférence permanente)
                  print('🚫 Option "Ne plus me demander" sélectionnée');
                  
                  locationController.setDontAskAgain(true);
                  setState(() {});
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Vous ne serez plus averti'),
                      duration: const Duration(seconds: 2),
                      backgroundColor: Colors.grey,
                    ),
                  );
                },
                child: Text(
                  'Ne plus me demander',
                  style: textRegular.copyWith(
                    fontSize: Dimensions.fontSizeExtraSmall,
                    color: Colors.grey[500],
                  ),
                ),
              ),
              const SizedBox(width: Dimensions.paddingSizeSmall),
              TextButton(
                onPressed: () {
                  // OPTION 4: Fermer simplement le prompt (pour cette fois seulement)
                  print('❌ Option "Fermer" sélectionnée');
                  
                  // Mais on le marque comme affiché pour ne pas réafficher dans cette session
                  locationController.hasShownRideForOtherPrompt == true;
                  setState(() {});
                },
                child: Text(
                  'Fermer',
                  style: textRegular.copyWith(
                    fontSize: Dimensions.fontSizeExtraSmall,
                    color: Colors.grey[500],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: GetBuilder<RideController>(builder: (rideController) {
          return BodyWidget(
            appBar: AppBarWidget(
              title: rideController.rideType == RideType.scheduleRide
                  ? 'schedule_trip_setup'.tr
                  : 'trip_setup'.tr,
              centerTitle: true,
              onBackPressed: () {
                if (Navigator.canPop(context)) {
                  Get.back();
                } else {
                  Get.offAll(() => const DashboardScreen());
                }
              },
            ),
            body: GetBuilder<LocationController>(
                builder: (locationController) {
                  // Vérifier si tous les trajets sont renseignés
                  bool hasValidRoute = locationController.fromAddress != null && 
                                      locationController.toAddress != null;
                  
                  // Vérifier si le point de départ a été modifié par rapport à la position initiale
                  bool isPickupModifiedFromInitial = locationController.isPickupModifiedFromInitial();
                  
                  // NOUVELLE CONDITION PLUS SIMPLE
                  bool showRideForOtherPrompt = hasValidRoute && 
                                                isPickupModifiedFromInitial && 
                                                !locationController.isRideForOther &&
                                                !locationController.dontAskAgain;

                  // Afficher dans les logs pour déboguer
                  print("🏁 BUILD - showRideForOtherPrompt: $showRideForOtherPrompt");
                  print("  - hasValidRoute: $hasValidRoute");
                  print("  - isPickupModifiedFromInitial: $isPickupModifiedFromInitial");
                  print("  - isRideForOther: ${locationController.isRideForOther}");
                  print("  - dontAskAgain: ${locationController.dontAskAgain}");
                  print("  - hasShownRideForOtherPrompt: ${locationController.hasShownRideForOtherPrompt}");

                  return Stack(clipBehavior: Clip.none, children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        Dimensions.paddingSizeDefault,
                        Dimensions.paddingSizeDefault,
                        Dimensions.paddingSizeDefault,
                        Dimensions.paddingSizeSmall,
                      ),
                      child: SingleChildScrollView(
                        controller: scrollController,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                           // RideCategoryWidget(),
                            const SizedBox(height: Dimensions.paddingSizeSmall),
                            
                            // Prompt : Commander pour quelqu'un d'autre (si conditions remplies)
                            if (showRideForOtherPrompt)
                              _buildRideForOtherPrompt(locationController),
                            
                            if (showRideForOtherPrompt) 
                              const SizedBox(height: Dimensions.paddingSizeSmall),
                            
                            // Si déjà activé pour quelqu'un d'autre, afficher le widget complet
                            if (locationController.isRideForOther)
                              _RideForOtherWidget(),
                            
                            if (locationController.isRideForOther) 
                              const SizedBox(height: Dimensions.paddingSizeSmall),
                            
                        //    PickupTimeDateWidget(),
                            const SizedBox(height: Dimensions.paddingSizeSmall),
                            
                            // Bouton pour réactiver le suivi automatique (si modifié manuellement)
                            _buildAutoTrackingButton(locationController),
                            
                            Row(
                              children: [
                                Text('set_your_location'.tr, style: textSemiBold),
                                _buildEnhancedLocationIndicator(locationController),
                              ],
                            ),
                            const SizedBox(height: Dimensions.paddingSizeSmall),
                            Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context)
                                    .hintColor
                                    .withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(
                                    Dimensions.paddingSizeSmall),
                              ),
                              child: Column(children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    _LocationFromToWidget(),
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                          top: Dimensions.paddingSizeDefault,
                                          right: Dimensions.paddingSizeDefault,
                                          bottom: Dimensions.paddingSizeDefault,
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            // Point de départ
                                            PickLocationWidget(
                                              locationType: LocationType.from,
                                              rideDetails: rideController.rideDetails,
                                              focusNode: pickLocationFocus,
                                              textEditingController:
                                              locationController
                                                  .pickupLocationController,
                                              isShowCrossButton: false,
                                              textFieldHint: 'pick_location'.tr,
                                              locationIconTap: () {
                                                RouteHelper.goPageAndHideTextField(
                                                  context,
                                                  PickMapScreen(
                                                    type: LocationType.from,
                                                    address:
                                                    locationController.fromAddress,
                                                  ),
                                                );
                                              },
                                              textFieldTap: () {
                                                setScrollAndDialogPosition(
                                                    LocationType.from,
                                                    locationController);
                                              },
                                              onSuggestionSelected: () {
                                                _pickupSelected = true;
                                                _checkAndTriggerSearch();
                                              },
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.symmetric(
                                                vertical: 2.0,
                                              ),
                                              child: Text('to'.tr,
                                                  style: textRegular.copyWith(
                                                      color: Theme.of(context)
                                                          .textTheme
                                                          .bodyMedium
                                                          ?.color)),
                                            ),

                                            // Section des arrêts
                                            _buildStopsSection(
                                                locationController, rideController),

                                            // Destination et bouton d'ajout
                                            Row(children: [
                                              Expanded(
                                                child: PickLocationWidget(
                                                  locationType: LocationType.to,
                                                  textFieldHint: 'destination'.tr,
                                                  rideDetails:
                                                  rideController.rideDetails,
                                                  focusNode:
                                                  destinationLocationFocus,
                                                  textEditingController:
                                                  locationController
                                                      .destinationLocationController,
                                                  isShowCrossButton: false,
                                                  locationIconTap: () {
                                                    RouteHelper
                                                        .goPageAndHideTextField(
                                                      context,
                                                      PickMapScreen(
                                                        type: LocationType.to,
                                                        address: locationController
                                                            .toAddress,
                                                      ),
                                                    );
                                                  },
                                                  textFieldTap: () {
                                                    setScrollAndDialogPosition(
                                                        LocationType.to,
                                                        locationController);
                                                  },
                                                  onSuggestionSelected: () {
                                                    _destinationSelected = true;
                                                    _checkAndTriggerSearch();
                                                  },
                                                ),
                                              ),
                                              SizedBox(width: Dimensions.paddingSizeSmall),
                                            _buildAddStopButton(locationController), //C'est ajouter d'autre arrêt
                                            ]),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    Dimensions.paddingSizeExtraLarge,
                                    0,
                                    Dimensions.paddingSizeExtraLarge,
                                    Dimensions.paddingSizeSmall,
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          'you_can_add_multiple_route_to'.tr,
                                          style: textRegular.copyWith(
                                            fontSize: Dimensions.fontSizeSmall,
                                            color: Theme.of(context)
                                                .textTheme
                                                .bodyMedium!
                                                .color!
                                                .withValues(alpha: 0.7),
                                          ),
                                        ),
                                      ),
                                      if (_hasStops(locationController))
                                        _buildRemoveAllStopsButton(locationController),
                                    ],
                                  ),
                                ),
                              ]),
                            ),
                            if (rideController.rideType == RideType.scheduleRide)
                              ReservationNoteWidget(globalKey: _key),
                            SizedBox(height: bottomWhiteSpace)
                          ],
                        ),
                      ),
                    ),

                    // Boîte de dialogue d'autocomplete
                    if (locationController.resultShow)
                      Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        child: InkWell(
                          onTap: () =>
                              locationController.setSearchResultShowHide(show: false),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Get.isDarkMode
                                  ? Theme.of(context).canvasColor
                                  : Theme.of(context).cardColor,
                              borderRadius: BorderRadius.circular(
                                  Dimensions.paddingSizeDefault),
                            ),
                            margin: EdgeInsets.fromLTRB(30, dialogTopPosition, 30, 0),
                            child: ListView.builder(
                              itemCount: locationController
                                  .predictionList?.data?.suggestions?.length ??
                                  0,
                              shrinkWrap: true,
                              padding: EdgeInsets.zero,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                return InkWell(
                                  onTap: () {
                                    Get.find<LocationController>().setLocation(
                                      fromSearch: true,
                                      locationController.predictionList?.data
                                          ?.suggestions?[index]
                                          .placePrediction
                                          ?.placeId ??
                                          '',
                                      locationController.predictionList?.data
                                          ?.suggestions?[index]
                                          .placePrediction
                                          ?.text
                                          ?.text ??
                                          '',
                                      null,
                                      type: locationController.locationType,
                                    ).then((_) {
                                      // Après avoir défini l'adresse, marquer comme sélectionné
                                      if (locationController.locationType == LocationType.from) {
                                        _pickupSelected = true;
                                      } else if (locationController.locationType == LocationType.to) {
                                        _destinationSelected = true;
                                      }
                                      _checkAndTriggerSearch();
                                    });
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: Dimensions.paddingSizeDefault,
                                      horizontal: Dimensions.paddingSizeSmall,
                                    ),
                                    child: Row(children: [
                                      const Icon(Icons.location_on),
                                      Expanded(
                                        child: Text(
                                          locationController.predictionList?.data
                                              ?.suggestions?[index]
                                              .placePrediction
                                              ?.text
                                              ?.text ??
                                              '',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: Theme.of(context)
                                              .textTheme
                                              .displayMedium!
                                              .copyWith(
                                            color: Theme.of(context)
                                                .textTheme
                                                .bodyLarge!
                                                .color,
                                            fontSize: Dimensions.fontSizeDefault,
                                          ),
                                        ),
                                      ),
                                    ]),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                  ]);
                }),
          );
        }),
        bottomNavigationBar: ProcessButtonWidget(
          pickLocationFocus: pickLocationFocus,
          destinationLocationFocus: destinationLocationFocus,
        
        ),
      ),
    );
  }

  // Vérifie si on peut ajouter plus d'arrêts
  bool _canAddMoreStops(LocationController locationController) {
    return Get.find<ConfigController>().config!.addIntermediatePoint! &&
        !locationController.extraThreeRoute;
  }

  // Vérifie s'il y a des arrêts
  bool _hasStops(LocationController locationController) {
    return locationController.extraOneRoute ||
        locationController.extraTwoRoute ||
        locationController.extraThreeRoute;
  }

  // Compte le nombre d'arrêts actuels
  int _getCurrentStopsCount(LocationController locationController) {
    int count = 0;
    if (locationController.extraOneRoute) count++;
    if (locationController.extraTwoRoute) count++;
    if (locationController.extraThreeRoute) count++;
    return count;
  }

  // Widget du bouton "Ajouter un arrêt"
  Widget _buildAddStopButton(LocationController locationController) {
    final currentStops = _getCurrentStopsCount(locationController);
    final canAddMore = _canAddMoreStops(locationController);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          width: 70,
          height: 3,
          margin: const EdgeInsets.only(bottom: 2),
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(1.5),
          ),
          child: Row(
            children: [
              for (int i = 0; i < 3; i++)
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 0.5),
                    decoration: BoxDecoration(
                      color: i < currentStops ? Theme.of(context).primaryColor : Colors.grey[300],
                      borderRadius: BorderRadius.circular(1),
                    ),
                  ),
                ),
            ],
          ),
        ),
        InkWell(
          onTap: canAddMore ? () {
            _addNewRoute(locationController);
          } : null,
          child: Container(
            height: 30,
            width: 70,
            decoration: BoxDecoration(
              color: canAddMore ? Theme.of(context).primaryColor : Colors.grey[400],
              borderRadius: BorderRadius.circular(
                Dimensions.paddingSizeExtraSmall,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.add,
                    color: canAddMore ? Colors.white : Colors.grey[200],
                    size: 14
                ),
                const SizedBox(width: 2),
                Text(
                  'Arrêt',
                  style: TextStyle(
                    color: canAddMore ? Colors.white : Colors.grey[200],
                    fontSize: 10,
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(left: 2),
                  padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '$currentStops/3',
                    style: TextStyle(
                      color: canAddMore ? Colors.white : Colors.grey[200],
                      fontSize: 8,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Widget du bouton "Supprimer tous les arrêts"
  Widget _buildRemoveAllStopsButton(LocationController locationController) {
    return InkWell(
      onTap: () {
        _showRemoveAllDialog(context, locationController);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeSmall,
          vertical: Dimensions.paddingSizeExtraSmall,
        ),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.1),
          borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
          border: Border.all(color: Colors.red.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.delete_forever,
              color: Colors.red,
              size: 14,
            ),
            const SizedBox(width: Dimensions.paddingSizeExtraSmall),
            Text(
              'supprimer_tout'.tr,
              style: textMedium.copyWith(
                fontSize: Dimensions.fontSizeExtraSmall,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Dialogue de confirmation suppression totale
  void _showRemoveAllDialog(BuildContext context, LocationController locationController) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('supprimer_tous_les_arrêts'.tr),
          content: Text('voulez_vous_supprimer_tous_les_arrêts_intermédiaires'.tr),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('annuler'.tr),
            ),
            TextButton(
              onPressed: () {
                _removeAllStops(locationController);
                Get.back();
              },
              child: Text('supprimer'.tr, style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  // Section des arrêts
  Widget _buildStopsSection(
      LocationController locationController, RideController rideController) {
    final routes = _getRoutesList(locationController);
    if (routes.isEmpty) return const SizedBox.shrink();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < routes.length; i++)
          Padding(
            padding: EdgeInsets.only(
              bottom: i < routes.length - 1 ? 0 : 0,
            ),
            child: _buildStopItem(
              routes[i],
              locationController,
              rideController,
              i,
              routes.length,
            ),
          ),
      ],
    );
  }

  // Widget d'un arrêt avec autocomplete fonctionnel
  Widget _buildStopItem(
      Map<String, dynamic> route,
      LocationController locationController,
      RideController rideController,
      int index,
      int totalStops,
      ) {
    final type = route['type'];
    final hint = route['hint'];
    final controller = route['controller'];
    final address = route['address'];

    return Container(
      margin: const EdgeInsets.only(top: 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Contrôles à gauche
          Container(
            width: 72,
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                if (index > 0)
                  InkWell(
                    onTap: () {
                      _moveStopUp(index, locationController);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Icon(
                        Icons.arrow_upward,
                        size: 16,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  )
                else
                  const SizedBox(width: 24),

                InkWell(
                  onTap: () {
                    _swapWithDestination(type, locationController);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Icon(
                      Icons.swap_vert,
                      size: 16,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ),

                if (index < totalStops - 1)
                  InkWell(
                    onTap: () {
                      _moveStopDown(index, locationController);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Icon(
                        Icons.arrow_downward,
                        size: 16,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  )
                else
                  const SizedBox(width: 24),
              ],
            ),
          ),

          // Contenu de l'arrêt avec PickLocationWidget corrigé
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: PickLocationWidget(
                      locationType: type,
                      textFieldHint: hint,
                      rideDetails: rideController.rideDetails,
                      focusNode: null,
                      textEditingController: controller,
                      isShowCrossButton: true,
                      locationIconTap: () {
                        RouteHelper.goPageAndHideTextField(
                          context,
                          PickMapScreen(
                            type: type,
                            address: address,
                          ),
                        );
                      },
                      textFieldTap: () {
                        // IMPORTANT: Déclenche l'autocomplete
                        setScrollAndDialogPosition(type, locationController);
                      },
                      onSuggestionSelected: () {
                        // Marquer comme sélectionné selon le type
                        if (type == LocationType.extraOne ||
                            type == LocationType.extraTwo ||
                            type == LocationType.extraThree) {
                          // Pour les arrêts, on ne déclenche pas la recherche
                        }
                      },
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      _showDeleteDialog(type, locationController);
                    },
                    icon: Icon(
                      Icons.delete,
                      color: Colors.red,
                      size: 18,
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 36,
                      minHeight: 36,
                    ),
                    tooltip: 'Supprimer cet arrêt',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Dialogue de confirmation suppression d'un arrêt
  void _showDeleteDialog(LocationType type, LocationController locationController) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('supprimer_l_arrêt'.tr),
          content: Text('voulez_vous_supprimer_cet_arrêt'.tr),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('annuler'.tr),
            ),
            TextButton(
              onPressed: () {
                Get.back();
                _removeStop(type, locationController);
              },
              child: Text('supprimer'.tr, style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  // Obtenir la liste des arrêts
  List<Map<String, dynamic>> _getRoutesList(LocationController locationController) {
    final List<Map<String, dynamic>> routes = [];

    if (locationController.extraOneRoute) {
      routes.add({
        'type': LocationType.extraOne,
        'hint': 'extra_route_one'.tr,
        'controller': locationController.extraRouteOneController,
        'address': locationController.extraRouteAddress,
      });
    }

    if (locationController.extraTwoRoute) {
      routes.add({
        'type': LocationType.extraTwo,
        'hint': 'extra_route_two'.tr,
        'controller': locationController.extraRouteTwoController,
        'address': locationController.extraRouteTwoAddress,
      });
    }

    if (locationController.extraThreeRoute) {
      routes.add({
        'type': LocationType.extraThree,
        'hint': 'extra_route_three'.tr,
        'controller': locationController.extraRouteThreeController,
        'address': locationController.extraRouteThreeAddress,
      });
    }

    return routes;
  }

  // Ajouter un nouvel arrêt
  void _addNewRoute(LocationController locationController) {
    if (!locationController.extraOneRoute) {
      locationController.extraOneRoute = true;
    } else if (!locationController.extraTwoRoute) {
      locationController.extraTwoRoute = true;
    } else if (!locationController.extraThreeRoute) {
      locationController.extraThreeRoute = true;
    }
    locationController.update();
    setState(() {});
  }

  // Déplacer un arrêt vers le haut
  void _moveStopUp(int index, LocationController locationController) {
    if (index <= 0) return;

    final routes = _getRoutesList(locationController);
    if (routes.length < 2) return;

    final temp = routes[index];
    routes[index] = routes[index - 1];
    routes[index - 1] = temp;

    _updateControllersWithNewOrder(routes, locationController);
  }

  // Déplacer un arrêt vers le bas
  void _moveStopDown(int index, LocationController locationController) {
    final routes = _getRoutesList(locationController);
    if (index >= routes.length - 1) return;

    final temp = routes[index];
    routes[index] = routes[index + 1];
    routes[index + 1] = temp;

    _updateControllersWithNewOrder(routes, locationController);
  }

  // Supprimer un arrêt
  void _removeStop(LocationType type, LocationController locationController) {
    switch (type) {
      case LocationType.extraOne:
        locationController.extraOneRoute = false;
        locationController.extraRouteOneController.clear();
        locationController.extraRouteAddress = null;
        break;
      case LocationType.extraTwo:
        locationController.extraTwoRoute = false;
        locationController.extraRouteTwoController.clear();
        locationController.extraRouteTwoAddress = null;
        break;
      case LocationType.extraThree:
        locationController.extraThreeRoute = false;
        locationController.extraRouteThreeController.clear();
        locationController.extraRouteThreeAddress = null;
        break;
      default:
        return;
    }

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Mettre à jour les contrôleurs avec le nouvel ordre
  void _updateControllersWithNewOrder(
      List<Map<String, dynamic>> routes, LocationController locationController) {
    locationController.extraOneRoute = false;
    locationController.extraTwoRoute = false;
    locationController.extraThreeRoute = false;

    locationController.extraRouteOneController.clear();
    locationController.extraRouteTwoController.clear();
    locationController.extraRouteThreeController.clear();

    locationController.extraRouteAddress = null;
    locationController.extraRouteTwoAddress = null;
    locationController.extraRouteThreeAddress = null;

    for (int i = 0; i < routes.length; i++) {
      final route = routes[i];
      final type = route['type'];
      final controller = route['controller'] as TextEditingController;
      final address = route['address'] as Address?;

      String currentText = controller.text;

      if (i == 0) {
        locationController.extraOneRoute = true;
        locationController.extraRouteOneController.text = currentText;
        locationController.extraRouteAddress = address;
      } else if (i == 1) {
        locationController.extraTwoRoute = true;
        locationController.extraRouteTwoController.text = currentText;
        locationController.extraRouteTwoAddress = address;
      } else if (i == 2) {
        locationController.extraThreeRoute = true;
        locationController.extraRouteThreeController.text = currentText;
        locationController.extraRouteThreeAddress = address;
      }
    }

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Échanger un arrêt avec la destination
  void _swapWithDestination(LocationType routeType, LocationController locationController) {
    final tempDestText = locationController.destinationLocationController.text;
    final tempDestAddress = locationController.toAddress;

    switch (routeType) {
      case LocationType.extraOne:
        final tempRouteText = locationController.extraRouteOneController.text;
        final tempRouteAddress = locationController.extraRouteAddress;
        locationController.extraRouteOneController.text = tempDestText;
        locationController.extraRouteAddress = tempDestAddress;
        locationController.destinationLocationController.text = tempRouteText;
        locationController.toAddress = tempRouteAddress;
        break;
      case LocationType.extraTwo:
        final tempRouteText = locationController.extraRouteTwoController.text;
        final tempRouteAddress = locationController.extraRouteTwoAddress;
        locationController.extraRouteTwoController.text = tempDestText;
        locationController.extraRouteTwoAddress = tempDestAddress;
        locationController.destinationLocationController.text = tempRouteText;
        locationController.toAddress = tempRouteAddress;
        break;
      case LocationType.extraThree:
        final tempRouteText = locationController.extraRouteThreeController.text;
        final tempRouteAddress = locationController.extraRouteThreeAddress;
        locationController.extraRouteThreeController.text = tempDestText;
        locationController.extraRouteThreeAddress = tempDestAddress;
        locationController.destinationLocationController.text = tempRouteText;
        locationController.toAddress = tempRouteAddress;
        break;
      default:
        return;
    }

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Supprimer tous les arrêts
  void _removeAllStops(LocationController locationController) {
    locationController.extraRouteOneController.clear();
    locationController.extraRouteTwoController.clear();
    locationController.extraRouteThreeController.clear();

    locationController.extraRouteAddress = null;
    locationController.extraRouteTwoAddress = null;
    locationController.extraRouteThreeAddress = null;

    locationController.extraOneRoute = false;
    locationController.extraTwoRoute = false;
    locationController.extraThreeRoute = false;

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Méthode corrigée pour positionner la boîte de dialogue d'autocomplete
  void setScrollAndDialogPosition(
      LocationType locationType, LocationController locationController) {

    // Ajuster le scroll comme dans la version originale
    scrollController.jumpTo(MediaQuery.of(context).size.height + Get.height * 0.3);

    // Calculer l'espace blanc en bas
    bottomWhiteSpace = Get.find<RideController>().rideType == RideType.scheduleRide
        ? (Get.height * 0.4 - (_key.currentContext?.size?.height ?? 0))
        : Get.height * 0.4;

    // Positionner la boîte de dialogue selon le type de champ (comme dans l'original)
    if (locationType == LocationType.from) {
      dialogTopPosition = Get.height * 0.2;
    } else if (locationType == LocationType.extraOne) {
      dialogTopPosition = locationController.extraTwoRoute ? Get.height * 0.18 : Get.height * 0.23;
    } else if (locationType == LocationType.extraTwo) {
      dialogTopPosition = Get.height * 0.23;
    } else if (locationType == LocationType.extraThree) {
      dialogTopPosition = Get.height * 0.23;
    } else if (locationType == LocationType.to) {
      dialogTopPosition = Get.height * 0.28;
    }

    setState(() {});
  }
}

class _LocationFromToWidget extends StatelessWidget {
  const _LocationFromToWidget();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        Dimensions.paddingSizeSmall,
        Dimensions.paddingSizeDefault,
        0,
        0,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: Dimensions.iconSizeLarge,
            child: Image.asset(
              Images.currentLocation,
              color: Theme.of(context).textTheme.bodyMedium!.color,
            ),
          ),
          Container(
            height: 40,
            width: 10,
            child: CustomDivider(
              height: 4,
              dashWidth: 0.8,
              axis: Axis.vertical,
              color: Theme.of(context)
                  .textTheme
                  .bodyMedium!
                  .color!
                  .withValues(alpha: 0.5),
            ),
          ),
          SizedBox(
            width: Dimensions.iconSizeMedium,
            child: Transform(
              alignment: Alignment.center,
              transform: Get.find<LocalizationController>().isLtr
                  ? Matrix4.rotationY(0)
                  : Matrix4.rotationY(math.pi),
              child: Image.asset(
                Images.activityDirection,
                color: Theme.of(context).textTheme.bodyMedium!.color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// WIDGET : Commander pour un autre
class _RideForOtherWidget extends StatefulWidget {
  const _RideForOtherWidget();

  @override
  State<_RideForOtherWidget> createState() => _RideForOtherWidgetState();
}

class _RideForOtherWidgetState extends State<_RideForOtherWidget> {
  final TextEditingController _phoneController = TextEditingController();
  final FocusNode _phoneFocusNode = FocusNode();
  bool _saveContact = false;

  @override
  void initState() {
    super.initState();
    // Initialiser avec les valeurs existantes si nécessaire
    final locationController = Get.find<LocationController>();
    if (locationController.isRideForOther) {
      _phoneController.text = locationController.beneficiaryPhone;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LocationController>(
      builder: (locationController) {
        return Container(
          margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
            border: Border.all(
              color: locationController.isRideForOther 
                ? Theme.of(context).primaryColor.withOpacity(0.5)
                : Colors.grey.withOpacity(0.2),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.05),
                blurRadius: 5,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              // En-tête avec switch
              Padding(
                padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: locationController.isRideForOther 
                          ? Theme.of(context).primaryColor.withOpacity(0.1)
                          : Colors.grey.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                      ),
                      child: Icon(
                        Icons.person_outline,
                        color: locationController.isRideForOther 
                          ? Theme.of(context).primaryColor
                          : Colors.grey,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: Dimensions.paddingSizeSmall),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Cette course est pour vous ou pour quelqu\'un d\'autre ?',
                            style: textRegular.copyWith(
                              fontSize: Dimensions.fontSizeSmall,
                              color: Colors.grey[600],
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            locationController.isRideForOther 
                              ? 'Pour quelqu\'un d\'autre' 
                              : 'Pour moi-même',
                            style: textSemiBold.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: locationController.isRideForOther 
                                ? Theme.of(context).primaryColor
                                : null,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: locationController.isRideForOther,
                      onChanged: (value) {
                        _toggleRideForOther(locationController, value: value);
                      },
                      activeColor: Theme.of(context).primaryColor,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ],
                ),
              ),
              
              // Champ de saisie du numéro si activé (pour quelqu'un d'autre)
              if (locationController.isRideForOther) ...[
                Container(
                  height: 1,
                  color: Colors.grey.withOpacity(0.2),
                  margin: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                ),
                Padding(
                  padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Numéro du destinataire',
                        style: textMedium.copyWith(
                          fontSize: Dimensions.fontSizeSmall,
                        ),
                      ),
                      const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _phoneController,
                              focusNode: _phoneFocusNode,
                              keyboardType: TextInputType.phone,
                              decoration: InputDecoration(
                                hintText: 'Ex: +225 07 89 45 12 34',
                                prefixIcon: Icon(
                                  Icons.phone,
                                  color: Theme.of(context).primaryColor,
                                  size: 18,
                                ),
                                filled: true,
                                fillColor: Theme.of(context).hintColor.withOpacity(0.05),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                                  borderSide: BorderSide.none,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: Dimensions.paddingSizeDefault,
                                  vertical: Dimensions.paddingSizeSmall,
                                ),
                              ),
                              onChanged: (value) {
                                locationController.setBeneficiaryPhone(value);
                              },
                            ),
                          ),
                          const SizedBox(width: Dimensions.paddingSizeSmall),
                          
                          // Bouton pour choisir depuis les contacts
                          InkWell(
                            onTap: () async {
                              _showContactsDialog(context, locationController);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Theme.of(context).primaryColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                              ),
                              child: Icon(
                                Icons.contacts,
                                color: Theme.of(context).primaryColor,
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                // Option pour sauvegarder le contact
                Padding(
                  padding: const EdgeInsets.only(
                    left: Dimensions.paddingSizeDefault,
                    right: Dimensions.paddingSizeDefault,
                    bottom: Dimensions.paddingSizeDefault,
                  ),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 20,
                        height: 20,
                        child: Checkbox(
                          value: _saveContact,
                          onChanged: (value) {
                            setState(() {
                              _saveContact = value ?? false;
                            });
                          },
                          activeColor: Theme.of(context).primaryColor,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          visualDensity: VisualDensity.compact,
                        ),
                      ),
                      const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                      Expanded(
                        child: Text(
                          'Sauvegarder ce contact',
                          style: textRegular.copyWith(
                            fontSize: Dimensions.fontSizeSmall,
                            color: Colors.grey[600],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
  
  void _toggleRideForOther(LocationController locationController, {required bool value}) {
    if (value) {
      // Activer (pour quelqu'un d'autre)
      locationController.setRideForOther(true);
      setState(() {}); // Forcer la mise à jour
    } else {
      // Désactiver (pour moi-même)
      _showConfirmationDialog(context, locationController);
    }
  }
  
  void _showConfirmationDialog(BuildContext context, LocationController locationController) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirmation'),
          content: Text('Voulez-vous vraiment commander pour vous-même ? Les informations du destinataire seront effacées.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Non'),
            ),
            TextButton(
              onPressed: () {
                locationController.setRideForOther(false);
                _phoneController.clear();
                Navigator.pop(context);
              },
              child: Text('Oui', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }
  
  void _showContactsDialog(BuildContext context, LocationController locationController) {
    // Liste de contacts simulée
    final List<Map<String, String>> mockContacts = [
      {'name': 'Marie Dupont', 'phone': '+225 07 89 45 12 34'},
      {'name': 'Jean Kouassi', 'phone': '+225 05 67 89 01 23'},
      {'name': 'Sophie Yao', 'phone': '+225 01 23 45 67 89'},
      {'name': 'Marc Konan', 'phone': '+225 09 87 65 43 21'},
      {'name': 'Aminata Diallo', 'phone': '+225 03 45 67 89 01'},
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.7,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: Dimensions.paddingSizeDefault),
              Text(
                'Choisir un contact',
                style: textBold.copyWith(
                  fontSize: Dimensions.fontSizeLarge,
                ),
              ),
              const SizedBox(height: Dimensions.paddingSizeDefault),
              
              // Barre de recherche
              TextField(
                decoration: InputDecoration(
                  hintText: 'Rechercher un contact',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[100],
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: Dimensions.paddingSizeSmall,
                  ),
                ),
              ),
              const SizedBox(height: Dimensions.paddingSizeDefault),
              
              // Liste des contacts
              Expanded(
                child: ListView.builder(
                  itemCount: mockContacts.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    final contact = mockContacts[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
                        child: Text(
                          contact['name']![0],
                          style: TextStyle(
                            color: Theme.of(context).primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text(
                        contact['name']!,
                        style: textMedium,
                      ),
                      subtitle: Text(
                        contact['phone']!,
                        style: textRegular.copyWith(
                          fontSize: Dimensions.fontSizeSmall,
                          color: Colors.grey[600],
                        ),
                      ),
                      onTap: () {
                        setState(() {
                          _phoneController.text = contact['phone']!;
                        });
                        locationController.setBeneficiaryPhone(contact['phone']!);
                        Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
  
  @override
  void dispose() {
    _phoneController.dispose();
    _phoneFocusNode.dispose();
    super.dispose();
  }
}