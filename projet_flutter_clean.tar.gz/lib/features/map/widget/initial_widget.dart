
// import 'package:flutter/material.dart';
// import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:get/get.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// import 'package:intl/intl.dart';
// import 'package:ride_sharing_user_app/common_widgets/button_widget.dart';
// import 'package:ride_sharing_user_app/common_widgets/custom_text_field.dart';
// import 'package:ride_sharing_user_app/common_widgets/expandable_bottom_sheet.dart';
// import 'package:ride_sharing_user_app/features/auth/controllers/auth_controller.dart';
// import 'package:ride_sharing_user_app/features/location/controllers/location_controller.dart';
// import 'package:ride_sharing_user_app/features/map/controllers/map_controller.dart';
// import 'package:ride_sharing_user_app/features/parcel/widgets/fare_input_widget.dart';
// import 'package:ride_sharing_user_app/features/parcel/widgets/route_widget.dart';
// import 'package:ride_sharing_user_app/features/payment/controllers/payment_controller.dart';
// import 'package:ride_sharing_user_app/features/profile/controllers/profile_controller.dart';
// import 'package:ride_sharing_user_app/features/ride/controllers/ride_controller.dart';
// import 'package:ride_sharing_user_app/features/ride/widgets/ride_category.dart';
// import 'package:ride_sharing_user_app/features/ride/widgets/trip_fare_summery.dart';
// import 'package:ride_sharing_user_app/features/set_destination/widget/schedule_date_time_picker_widget.dart';
// import 'package:ride_sharing_user_app/features/splash/controllers/config_controller.dart';
// import 'package:ride_sharing_user_app/features/trip/screens/trip_details_screen.dart';
// import 'package:ride_sharing_user_app/helper/display_helper.dart';
// import 'package:ride_sharing_user_app/helper/ride_controller_helper.dart';
// import 'package:ride_sharing_user_app/util/dimensions.dart';
// import 'package:ride_sharing_user_app/util/images.dart';
// import 'package:ride_sharing_user_app/util/styles.dart';


// class InitialWidget extends StatefulWidget {
//   final GlobalKey<ExpandableBottomSheetState> expandableKey;
//   const InitialWidget({super.key, required this.expandableKey});

//   @override
//   State<InitialWidget> createState() => _InitialWidgetState();
// }

// class _InitialWidgetState extends State<InitialWidget> {
// //  String? zoneExtraFareReason;

 
//   @override
//   void initState() {
//     var rideController = Get.find<RideController>();
//     if(Get.find<PaymentController>().paymentType == 'wallet' &&
//         (rideController.discountAmount.toDouble() > 0 ? rideController.discountFare : rideController.estimatedFare) >
//             Get.find<ProfileController>().profileModel!.data!.wallet!.walletBalance!
//     ){
//       Get.find<PaymentController>().setPaymentType(0);
//     }
 

//     super.initState();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<RideController>(builder: (rideController){
//       return GetBuilder<LocationController>(builder: (locationController){
//         return Column(mainAxisSize: MainAxisSize.min, children:  [
//               RideCategoryWidget(onTap:(value) async {
//                 if(rideController.isCouponApplicable){
//                   await Future.delayed(const Duration(milliseconds: 500));
//                   widget.expandableKey.currentState?.expand(duration: 1000);
//                 }else{
//                   widget.expandableKey.currentState?.contract(duration: 500);
//                   widget.expandableKey.currentState?.expand(duration: 1000);
//                 }

//               }),
//           const SizedBox(height: Dimensions.paddingSizeDefault),

//           Container(
//             decoration: BoxDecoration(
//               color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
//               borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall)
//             ),
//             padding: EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall, horizontal: Dimensions.paddingSizeDefault),
//             child: Row(spacing: Dimensions.paddingSizeSmall, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
//              //Text('pickup_time'.tr, style: textRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),

//               InkWell(
//                 onTap: (){
//                   if(Get.find<ConfigController>().config?.scheduleTripStatus ?? false){
//                     Get.bottomSheet(const ScheduleDateTimePickerWidget(),enableDrag: false, isScrollControlled: true);
//                   }
//                 },
//                 child: ConstrainedBox(
//                   constraints: BoxConstraints(
//                     maxWidth: MediaQuery.of(context).size.width * 0.6, // Limit width to 60% of screen
//                   ),
//                   child: Row(spacing: Dimensions.paddingSizeExtraSmall, mainAxisSize: MainAxisSize.min, children: [
//                     Image.asset(
//                       rideController.rideType == RideType.scheduleRide ?
//                         Images.scheduleCalenderIcon : Images.clockIcon,
//                         height: 14,width: 14,
//                     ),

//                     Flexible(
//                       child: Text(
//                         rideController.rideType == RideType.scheduleRide ?
//                         '${'schedule'.tr}: ${
//                             DateFormat('d MMM y').format(RideControllerHelper.dateFormatToShow(rideController.scheduleTripDate))}, '
//                             '${DateFormat('hh:mm a').format(RideControllerHelper.timeFormatToShow(rideController.scheduleTripTime))}' :
//                         'pickup_now'.tr,
//                         style: textBold.copyWith(fontSize: Dimensions.fontSizeSmall, overflow: TextOverflow.ellipsis),
//                       ),
//                     ),

//                     if(rideController.rideType == RideType.regularRide)
//                       Icon(Icons.keyboard_arrow_down_outlined)
//                   ]),
//                 ),
//               )
//             ]),
//           ),
//           const SizedBox(height: Dimensions.paddingSizeDefault),

//          RouteWidget(
//             totalDistance: rideController.fareList.isEmpty ? '0' :
//             rideController.fareList[rideController.rideCategoryIndex].estimatedDistance ?? '0',
//             fromAddress: locationController.fromAddress?.address??'',
//             extraOneAddress: locationController.extraRouteAddress?.address ?? '',
//             extraTwoAddress: locationController.extraRouteTwoAddress?.address ?? '',
//             extraThreeAddress: locationController.extraRouteThreeAddress?.address ?? '',
//             toAddress: locationController.toAddress?.address??'',
//             entrance: locationController.entranceController.text,
//           ),
//           const SizedBox(height: Dimensions.paddingSizeDefault),

//           if(rideController.fareList[rideController.rideCategoryIndex].extraFareReason != '') ...[
//             Text('${'fares_are_a_bit_higher'.tr}${rideController.fareList[rideController.rideCategoryIndex].extraFareReason}', style: textRegular.copyWith(color: Theme.of(context).colorScheme.inverseSurface,fontSize: 11), textAlign: TextAlign.center),
//             const SizedBox(height: Dimensions.paddingSizeExtraSmall),
//           ],

//           const SizedBox(height: Dimensions.paddingSizeSmall),

//           TripFareSummery(
//             tripFare: rideController.estimatedFare, fromParcel: false,
//             discountFare: rideController.discountFare, discountAmount: rideController.discountAmount,
//           ),
//           const SizedBox(height: Dimensions.paddingSizeDefault), 

//           if(rideController.isCouponApplicable)...[
//             Align(alignment: Alignment.centerRight,
//               child: Container(
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: Dimensions.paddingSizeSmall,
//                     vertical: Dimensions.paddingSizeExtraSmall,
//                   ),
//                   decoration: BoxDecoration(
//                     color: Theme.of(context).primaryColor.withValues(alpha:0.15),
//                     borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                   ),
//                   child: Text('coupon_applied'.tr,style: textBold.copyWith(color: Theme.of(context).primaryColor))
//               ),
//             ),
//             const SizedBox(height: Dimensions.paddingSizeDefault),
//           ],

//         // CustomTextField(
//         //     prefix: false,
//         //     borderRadius: Dimensions.radiusSmall,
//         //     hintText: "add_note".tr,
//         //     controller: rideController.noteController,
//         //     onTap: () async{
//         //       await Future.delayed(const Duration(milliseconds: 500));
//         //       widget.expandableKey.currentState?.expand(duration: 1000);
//         //     },
//         //   ),
//           const SizedBox(height: Dimensions.paddingSizeDefault),

//           rideController.isLoading || rideController.isSubmit ?
//           Center(child: SpinKitCircle(color: Theme.of(context).primaryColor, size: 40.0)) :
//           (Get.find<ConfigController>().config!.bidOnFare! && rideController.rideType != RideType.scheduleRide) ?
//           FareInputWidget(
//             expandableKey: widget.expandableKey,
//             fromRide: true,
//             fare: rideController.discountAmount.toDouble() > 0 ?
//             rideController.discountFare.toString() :
//             rideController.estimatedFare.toString(),
//           ) :
//          ButtonWidget(buttonText: rideController.rideType == RideType.regularRide ? "order".tr : "to_reserve".tr, onPressed: () {
//             if(rideController.rideType == RideType.regularRide) {
//               _sendFindRiderRequest(rideController);
//             }else{
//               rideController.submitRideRequest(rideController.noteController.text, false).then((value){
//                 if(value.statusCode == 200){
//                   Get.find<MapController>().initializeData();
//                   showCustomSnackBar(
//                       '${'your_trip'.tr} #${rideController.tripDetails?.refId} ${'has_been_successfully_scheduled'.tr}',
//                       subMessage: 'you_will_be_notified_when_a_driver_start_for_your'.tr
//                   );
//                   Get.offAll(() =>  TripDetailsScreen(tripId: rideController.tripDetails?.id ?? ''));
//                 }
//               });
//             }
//           }),
//         ]);
//       });
//     });
//   }


//   void _sendFindRiderRequest(RideController rideController){
//     rideController.submitRideRequest(rideController.noteController.text, false).then((value) {
//       if (value.statusCode == 200) {
//         Get.find<AuthController>().saveFindingRideCreatedTime();
//         rideController.updateRideCurrentState(RideState.findingRider);
//         Get.find<MapController>().initializeData();
//         Get.find<MapController>().setOwnCurrentLocation(
//             LatLng(
//                 Get.find<LocationController>().fromAddress?.latitude ?? 0,
//                 Get.find<LocationController>().fromAddress?.longitude ?? 0
//             )
//         );
//         Get.find<MapController>().notifyMapController();
//       }
//     });
//   }
// }

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'dart:math' as math;
import 'package:ride_sharing_user_app/common_widgets/button_widget.dart';
import 'package:ride_sharing_user_app/common_widgets/custom_text_field.dart';
import 'package:ride_sharing_user_app/common_widgets/expandable_bottom_sheet.dart';
import 'package:ride_sharing_user_app/features/auth/controllers/auth_controller.dart';
import 'package:ride_sharing_user_app/features/location/controllers/location_controller.dart';
import 'package:ride_sharing_user_app/features/map/controllers/map_controller.dart';
import 'package:ride_sharing_user_app/features/parcel/widgets/fare_input_widget.dart';
import 'package:ride_sharing_user_app/features/parcel/widgets/route_widget.dart';
import 'package:ride_sharing_user_app/features/payment/controllers/payment_controller.dart';
import 'package:ride_sharing_user_app/features/profile/controllers/profile_controller.dart';
import 'package:ride_sharing_user_app/features/ride/controllers/ride_controller.dart';
import 'package:ride_sharing_user_app/features/ride/widgets/ride_category.dart';
import 'package:ride_sharing_user_app/features/ride/widgets/trip_fare_summery.dart';
import 'package:ride_sharing_user_app/features/set_destination/widget/schedule_date_time_picker_widget.dart';
import 'package:ride_sharing_user_app/features/splash/controllers/config_controller.dart';
import 'package:ride_sharing_user_app/features/trip/screens/trip_details_screen.dart';
import 'package:ride_sharing_user_app/helper/display_helper.dart';
import 'package:ride_sharing_user_app/helper/ride_controller_helper.dart';
import 'package:ride_sharing_user_app/helper/route_helper.dart';
import 'package:ride_sharing_user_app/util/dimensions.dart';
import 'package:ride_sharing_user_app/util/images.dart';
import 'package:ride_sharing_user_app/util/styles.dart';
import 'package:ride_sharing_user_app/features/location/view/pick_map_screen.dart';
import 'package:ride_sharing_user_app/features/set_destination/widget/pick_location_widget.dart';
import 'package:ride_sharing_user_app/localization/localization_controller.dart';
import 'package:ride_sharing_user_app/common_widgets/divider_widget.dart';
import 'package:ride_sharing_user_app/features/address/domain/models/address_model.dart';


class InitialWidget extends StatefulWidget {
  final GlobalKey<ExpandableBottomSheetState> expandableKey;
    
  const InitialWidget({super.key, required this.expandableKey});
 

  @override
  State<InitialWidget> createState() => _InitialWidgetState();
}

class _InitialWidgetState extends State<InitialWidget> {
  double dialogTopPosition = 0;
  double bottomWhiteSpace = 0;
  final GlobalKey _key = GlobalKey();
  Timer? _debounceTimer;
  

  @override
  void initState() {
    var rideController = Get.find<RideController>();
    if(Get.find<PaymentController>().paymentType == 'wallet' &&
        (rideController.discountAmount.toDouble() > 0 ? rideController.discountFare : rideController.estimatedFare) >
            Get.find<ProfileController>().profileModel!.data!.wallet!.walletBalance!
    ){
      Get.find<PaymentController>().setPaymentType(0);
    }
    super.initState();
  }

  @override
  void dispose() {
    _debounceTimer?.cancel();
    super.dispose();
  }

  // Méthode pour déclencher le calcul automatique
  Future<void> _triggerAutoCalculate() async {
    final locationController = Get.find<LocationController>();
    final rideController = Get.find<RideController>();
    final mapController = Get.find<MapController>();
    
    if (locationController.fromAddress == null || locationController.toAddress == null) {
      return;
    }
    
    // Annuler le timer précédent
    _debounceTimer?.cancel();
    
    // Petit délai pour éviter trop d'appels
    _debounceTimer = Timer(const Duration(milliseconds: 800), () async {
      if (rideController.loading) return;
      
      print("🔄 Calcul automatique déclenché avec les arrêts");
      
      try {
        // Appeler l'API pour calculer le tarif
        var response = await rideController.getEstimatedFare(false);
        
        if (response.statusCode == 200) {
          print("✅ Tarif recalculé avec succès");
          
          // Mettre à jour la map avec tous les points
          await _updateMapWithStops();
          
          // Afficher un message de confirmation
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Itinéraire mis à jour avec ${_getCurrentStopsCount(locationController)} arrêt(s)'),
                duration: const Duration(seconds: 2),
                backgroundColor: Colors.green,
              ),
            );
          }
        }
      } catch (e) {
        print("❌ Erreur lors du calcul: $e");
      }
    });
  }
  
  // Méthode pour mettre à jour la map avec tous les points du trajet
  Future<void> _updateMapWithStops() async {
    final mapController = Get.find<MapController>();
    final locationController = Get.find<LocationController>();
    
    // Collecter tous les points du trajet dans l'ordre
    List<LatLng> allPoints = [];
    
    // Point de départ
    if (locationController.fromAddress?.latitude != null && 
        locationController.fromAddress?.longitude != null) {
      allPoints.add(LatLng(
        locationController.fromAddress!.latitude!,
        locationController.fromAddress!.longitude!,
      ));
    }
    
    // Arrêt 1
    if (locationController.extraRouteAddress?.latitude != null && 
        locationController.extraRouteAddress?.longitude != null) {
      allPoints.add(LatLng(
        locationController.extraRouteAddress!.latitude!,
        locationController.extraRouteAddress!.longitude!,
      ));
    }
    
    // Arrêt 2
    if (locationController.extraRouteTwoAddress?.latitude != null && 
        locationController.extraRouteTwoAddress?.longitude != null) {
      allPoints.add(LatLng(
        locationController.extraRouteTwoAddress!.latitude!,
        locationController.extraRouteTwoAddress!.longitude!,
      ));
    }
    
    // Arrêt 3
    if (locationController.extraRouteThreeAddress?.latitude != null && 
        locationController.extraRouteThreeAddress?.longitude != null) {
      allPoints.add(LatLng(
        locationController.extraRouteThreeAddress!.latitude!,
        locationController.extraRouteThreeAddress!.longitude!,
      ));
    }
    
    // Destination
    if (locationController.toAddress?.latitude != null && 
        locationController.toAddress?.longitude != null) {
      allPoints.add(LatLng(
        locationController.toAddress!.latitude!,
        locationController.toAddress!.longitude!,
      ));
    }
    
    // Afficher tous les points sur la map
    if (allPoints.length >= 2) {
      await mapController.showMultipleMarkersOnMap(allPoints);
      print("🗺️ Carte mise à jour avec ${allPoints.length} points");
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RideController>(builder: (rideController){
      return GetBuilder<LocationController>(builder: (locationController){
        return Column(mainAxisSize: MainAxisSize.min, children: [
          RideCategoryWidget(onTap:(value) async {
            if(rideController.isCouponApplicable){
              await Future.delayed(const Duration(milliseconds: 500));
              widget.expandableKey.currentState?.expand(duration: 1000);
            }else{
              widget.expandableKey.currentState?.contract(duration: 500);
              widget.expandableKey.currentState?.expand(duration: 1000);
            }
          }),
          const SizedBox(height: Dimensions.paddingSizeDefault),

          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall)
            ),
            padding: EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall, horizontal: Dimensions.paddingSizeDefault),
            child: Row(spacing: Dimensions.paddingSizeSmall, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              InkWell(
                onTap: (){
                  if(Get.find<ConfigController>().config?.scheduleTripStatus ?? false){
                    Get.bottomSheet(const ScheduleDateTimePickerWidget(),enableDrag: false, isScrollControlled: true);
                  }
                },
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.6,
                  ),
                  child: Row(spacing: Dimensions.paddingSizeExtraSmall, mainAxisSize: MainAxisSize.min, children: [
                    Image.asset(
                      rideController.rideType == RideType.scheduleRide ?
                        Images.scheduleCalenderIcon : Images.clockIcon,
                        height: 14,width: 14,
                    ),
                    Flexible(
                      child: Text(
                        rideController.rideType == RideType.scheduleRide ?
                        '${'schedule'.tr}: ${
                            DateFormat('d MMM y').format(RideControllerHelper.dateFormatToShow(rideController.scheduleTripDate))}, '
                            '${DateFormat('hh:mm a').format(RideControllerHelper.timeFormatToShow(rideController.scheduleTripTime))}' :
                        'pickup_now'.tr,
                        style: textBold.copyWith(fontSize: Dimensions.fontSizeSmall, overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    if(rideController.rideType == RideType.regularRide)
                      Icon(Icons.keyboard_arrow_down_outlined)
                  ]),
                ),
              )
            ]),
          ),
          const SizedBox(height: Dimensions.paddingSizeDefault),

          // Section principale avec les adresses et arrêts
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).hintColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                ),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _LocationFromToWidget(),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(
                              top: Dimensions.paddingSizeDefault,
                              right: Dimensions.paddingSizeDefault,
                              bottom: Dimensions.paddingSizeDefault,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Point de départ
                                PickLocationWidget(
                                  locationType: LocationType.from,
                                  rideDetails: rideController.rideDetails,
                                  focusNode: null,
                                  textEditingController: locationController.pickupLocationController,
                                  isShowCrossButton: false,
                                  textFieldHint: 'pick_location'.tr,
                                  locationIconTap: () {
                                    RouteHelper.goPageAndHideTextField(
                                      context,
                                      PickMapScreen(
                                        type: LocationType.from,
                                        address: locationController.fromAddress,
                                      ),
                                    );
                                  },
                                  textFieldTap: () {
                                    setScrollAndDialogPosition(LocationType.from, locationController);
                                  },
                                  onSuggestionSelected: () {
                                    _triggerAutoCalculate();
                                  },
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 2.0),
                                  child: Text('to'.tr,
                                      style: textRegular.copyWith(
                                          color: Theme.of(context).textTheme.bodyMedium?.color)),
                                ),

                                // Section des arrêts
                                _buildStopsSection(locationController, rideController),

                                // Destination et bouton d'ajout
                                Row(children: [
                                  Expanded(
                                    child: PickLocationWidget(
                                      locationType: LocationType.to,
                                      textFieldHint: 'destination'.tr,
                                      rideDetails: rideController.rideDetails,
                                      focusNode: null,
                                      textEditingController: locationController.destinationLocationController,
                                      isShowCrossButton: false,
                                      locationIconTap: () {
                                        RouteHelper.goPageAndHideTextField(
                                          context,
                                          PickMapScreen(
                                            type: LocationType.to,
                                            address: locationController.toAddress,
                                          ),
                                        );
                                      },
                                      textFieldTap: () {
                                        setScrollAndDialogPosition(LocationType.to, locationController);
                                      },
                                      onSuggestionSelected: () {
                                        _triggerAutoCalculate();
                                      },
                                    ),
                                  ),
                                  SizedBox(width: Dimensions.paddingSizeSmall),
                                  _buildAddStopButton(locationController),
                                ]),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(
                        Dimensions.paddingSizeExtraLarge,
                        0,
                        Dimensions.paddingSizeExtraLarge,
                        Dimensions.paddingSizeSmall,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              'you_can_add_multiple_route_to'.tr,
                              style: textRegular.copyWith(
                                fontSize: Dimensions.fontSizeSmall,
                                color: Theme.of(context).textTheme.bodyMedium!.color!.withValues(alpha: 0.7),
                              ),
                            ),
                          ),
                          if (_hasStops(locationController))
                            _buildRemoveAllStopsButton(locationController),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Boîte de dialogue d'autocomplete
              if (locationController.resultShow)
                Positioned(
                  top: dialogTopPosition,
                  left: 0,
                  right: 0,
                  child: InkWell(
                    onTap: () => locationController.setSearchResultShowHide(show: false),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Get.isDarkMode
                            ? Theme.of(context).canvasColor
                            : Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
                      ),
                      margin: EdgeInsets.fromLTRB(30, 0, 30, 0),
                      child: ListView.builder(
                        itemCount: locationController.predictionList?.data?.suggestions?.length ?? 0,
                        shrinkWrap: true,
                        padding: EdgeInsets.zero,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              Get.find<LocationController>().setLocation(
                                fromSearch: true,
                                locationController.predictionList?.data?.suggestions?[index]
                                    .placePrediction?.placeId ?? '',
                                locationController.predictionList?.data?.suggestions?[index]
                                    .placePrediction?.text?.text ?? '',
                                null,
                                type: locationController.locationType,
                              ).then((_) {
                                _triggerAutoCalculate();
                              });
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: Dimensions.paddingSizeDefault,
                                horizontal: Dimensions.paddingSizeSmall,
                              ),
                              child: Row(children: [
                                const Icon(Icons.location_on),
                                Expanded(
                                  child: Text(
                                    locationController.predictionList?.data?.suggestions?[index]
                                        .placePrediction?.text?.text ?? '',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(context).textTheme.displayMedium!.copyWith(
                                      color: Theme.of(context).textTheme.bodyLarge!.color,
                                      fontSize: Dimensions.fontSizeDefault,
                                    ),
                                  ),
                                ),
                              ]),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: Dimensions.paddingSizeDefault),

          if(rideController.fareList.isNotEmpty && 
             rideController.fareList[rideController.rideCategoryIndex].extraFareReason != '') ...[
            Text('${'fares_are_a_bit_higher'.tr}${rideController.fareList[rideController.rideCategoryIndex].extraFareReason}', 
                 style: textRegular.copyWith(color: Theme.of(context).colorScheme.inverseSurface,fontSize: 11), 
                 textAlign: TextAlign.center),
            const SizedBox(height: Dimensions.paddingSizeExtraSmall),
          ],

          const SizedBox(height: Dimensions.paddingSizeSmall),

          TripFareSummery(
            tripFare: rideController.estimatedFare, 
            fromParcel: false,
            discountFare: rideController.discountFare, 
            discountAmount: rideController.discountAmount,
          ),
          const SizedBox(height: Dimensions.paddingSizeDefault), 

          if(rideController.isCouponApplicable)...[
            Align(alignment: Alignment.centerRight,
              child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: Dimensions.paddingSizeSmall,
                    vertical: Dimensions.paddingSizeExtraSmall,
                  ),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withValues(alpha:0.15),
                    borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                  ),
                  child: Text('coupon_applied'.tr,style: textBold.copyWith(color: Theme.of(context).primaryColor))
              ),
            ),
            const SizedBox(height: Dimensions.paddingSizeDefault),
          ],

          rideController.isLoading || rideController.isSubmit ?
          Center(child: SpinKitCircle(color: Theme.of(context).primaryColor, size: 40.0)) :
          (Get.find<ConfigController>().config!.bidOnFare! && rideController.rideType != RideType.scheduleRide) ?
          FareInputWidget(
            expandableKey: widget.expandableKey,
            fromRide: true,
            fare: rideController.discountAmount.toDouble() > 0 ?
            rideController.discountFare.toString() :
            rideController.estimatedFare.toString(),
          ) :
          ButtonWidget(
            buttonText: rideController.rideType == RideType.regularRide ? "order".tr : "to_reserve".tr, 
            onPressed: () {
              if(rideController.rideType == RideType.regularRide) {
                _sendFindRiderRequest(rideController);
              }else{
                rideController.submitRideRequest(rideController.noteController.text, false).then((value){
                  if(value.statusCode == 200){
                    Get.find<MapController>().initializeData();
                    showCustomSnackBar(
                        '${'your_trip'.tr} #${rideController.tripDetails?.refId} ${'has_been_successfully_scheduled'.tr}',
                        subMessage: 'you_will_be_notified_when_a_driver_start_for_your'.tr
                    );
                    Get.offAll(() => TripDetailsScreen(tripId: rideController.tripDetails?.id ?? ''));
                  }
                });
              }
            },
          ),
        ]);
      });
    });
  }

  // Vérifie si on peut ajouter plus d'arrêts
  bool _canAddMoreStops(LocationController locationController) {
    return Get.find<ConfigController>().config!.addIntermediatePoint! &&
        !locationController.extraThreeRoute;
  }

  // Vérifie s'il y a des arrêts
  bool _hasStops(LocationController locationController) {
    return locationController.extraOneRoute ||
        locationController.extraTwoRoute ||
        locationController.extraThreeRoute;
  }

  // Compte le nombre d'arrêts actuels
  int _getCurrentStopsCount(LocationController locationController) {
    int count = 0;
    if (locationController.extraOneRoute) count++;
    if (locationController.extraTwoRoute) count++;
    if (locationController.extraThreeRoute) count++;
    return count;
  }

  // Widget du bouton "Ajouter un arrêt"
  Widget _buildAddStopButton(LocationController locationController) {
    final currentStops = _getCurrentStopsCount(locationController);
    final canAddMore = _canAddMoreStops(locationController);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          width: 70,
          height: 3,
          margin: const EdgeInsets.only(bottom: 2),
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(1.5),
          ),
          child: Row(
            children: [
              for (int i = 0; i < 3; i++)
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 0.5),
                    decoration: BoxDecoration(
                      color: i < currentStops ? Theme.of(context).primaryColor : Colors.grey[300],
                      borderRadius: BorderRadius.circular(1),
                    ),
                  ),
                ),
            ],
          ),
        ),
        InkWell(
          onTap: canAddMore ? () {
            _showAddStopBottomSheet(context, locationController);
          } : null,
          child: Tooltip(
            message: 'Ajouter un arrêt intermédiaire ($currentStops/3)',
            child: Container(
              height: 30,
              width: 70,
              decoration: BoxDecoration(
                color: canAddMore ? Theme.of(context).primaryColor : Colors.grey[400],
                borderRadius: BorderRadius.circular(Dimensions.paddingSizeExtraSmall),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add,
                      color: canAddMore ? Colors.white : Colors.grey[200],
                      size: 14
                  ),
                  const SizedBox(width: 2),
                  Text(
                    'Arrêt',
                    style: TextStyle(
                      color: canAddMore ? Colors.white : Colors.grey[200],
                      fontSize: 10,
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(left: 2),
                    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      '$currentStops/3',
                      style: TextStyle(
                        color: canAddMore ? Colors.white : Colors.grey[200],
                        fontSize: 8,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Méthode pour afficher un BottomSheet pour ajouter un arrêt
  // Méthode pour afficher un BottomSheet pour ajouter un arrêt (CORRIGÉE)
// Méthode pour afficher un BottomSheet pour ajouter un arrêt (AVEC AUTOCOMPLETE VISIBLE)

// Méthode pour afficher un BottomSheet pour ajouter un arrêt (AVEC AUTOCOMPLETE VISIBLE)
// Méthode pour afficher un BottomSheet pour ajouter un arrêt (AVEC AUTOCOMPLETE VISIBLE)
void _showAddStopBottomSheet(BuildContext context, LocationController locationController) {
  final TextEditingController stopController = TextEditingController();
  final FocusNode stopFocusNode = FocusNode();
  LocationType nextStopType = _getNextStopType(locationController);
  final scrollController = ScrollController();
  
  // Désactiver temporairement l'autocomplete existant pour éviter les conflits
  locationController.setSearchResultShowHide(show: false);
  
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return GestureDetector(
        onTap: () {
          // Cacher le clavier quand on tape en dehors du champ
          FocusScope.of(context).unfocus();
        },
        child: Container(
          height: MediaQuery.of(context).size.height * 0.7, // Hauteur fixe
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(Dimensions.radiusDefault),
                topRight: Radius.circular(Dimensions.radiusDefault),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Handle pour glisser
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(top: 8, bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.grey[400],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                
                // Titre
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Ajouter un arrêt',
                        style: textBold.copyWith(
                          fontSize: Dimensions.fontSizeLarge,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                ),
                
                // Indicateur de progression
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: Dimensions.paddingSizeSmall,
                      vertical: Dimensions.paddingSizeExtraSmall,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.info_outline,
                          size: 16,
                          color: Theme.of(context).primaryColor,
                        ),
                        const SizedBox(width: Dimensions.paddingSizeExtraSmall),
                        Text(
                          'Arrêt ${_getCurrentStopsCount(locationController) + 1}/3',
                          style: textMedium.copyWith(
                            fontSize: Dimensions.fontSizeSmall,
                            color: Theme.of(context).primaryColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: Dimensions.paddingSizeDefault),
                
                // Zone scrollable pour le contenu principal
                Expanded(
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeDefault),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Widget de saisie
                        PickLocationWidget(
                          locationType: nextStopType,
                          textFieldHint: 'Saisissez l\'adresse de l\'arrêt',
                          rideDetails: Get.find<RideController>().rideDetails,
                          focusNode: stopFocusNode,
                          textEditingController: stopController,
                          isShowCrossButton: true,
                          locationIconTap: () {
                            Navigator.pop(context);
                            RouteHelper.goPageAndHideTextField(
                              context,
                              PickMapScreen(
                                type: nextStopType,
                                address: null,
                              ),
                            );
                          },
                          textFieldTap: () {
                            // On utilise maintenant notre propre autocomplete
                          },
                          onSuggestionSelected: () {
                            // Ne rien faire ici, on utilise notre propre mécanisme
                          },
                        ),
                        
                        const SizedBox(height: Dimensions.paddingSizeSmall),
                        
                        // Zone d'autocomplete personnalisée
                        GetBuilder<LocationController>(
                          builder: (locController) {
                            if (!locController.resultShow || stopController.text.isEmpty) {
                              return const SizedBox.shrink();
                            }
                            
                            final suggestions = locController.predictionList?.data?.suggestions ?? [];
                            
                            if (suggestions.isEmpty) {
                              return const SizedBox.shrink();
                            }
                            
                            return Container(
                              constraints: BoxConstraints(
                                maxHeight: 300,
                              ),
                              decoration: BoxDecoration(
                                color: Get.isDarkMode
                                    ? Theme.of(context).canvasColor
                                    : Theme.of(context).cardColor,
                                borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
                                border: Border.all(
                                  color: Colors.grey.withOpacity(0.3),
                                ),
                              ),
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: suggestions.length,
                                itemBuilder: (context, index) {
                                  final suggestion = suggestions[index];
                                  final placeText = suggestion.placePrediction?.text?.text ?? '';
                                  final placeId = suggestion.placePrediction?.placeId ?? '';
                                  
                                  return InkWell(
                                    onTap: () async {
                                      try {
                                        // Sélectionner l'adresse avec la bonne signature
                                        await locController.setLocation(
                                          placeId,           // placeID
                                          placeText,         // address
                                          null,              // mapController (null car pas besoin)
                                          type: nextStopType,
                                          fromSearch: true,
                                        );
                                        
                                        // Mettre à jour le contrôleur
                                        stopController.text = placeText;
                                        
                                        // Ajouter l'arrêt
                                        _addStopWithAddress(nextStopType, locationController, placeText);
                                        
                                        // Fermer le bottom sheet
                                        if (context.mounted) {
                                          Navigator.pop(context);
                                        }
                                        
                                        // Petit délai
                                        await Future.delayed(const Duration(milliseconds: 300));
                                        
                                        // Déclencher le calcul
                                        await _triggerAutoCalculate();
                                        
                                        // Message de confirmation
                                        if (context.mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: Text('Arrêt ajouté avec succès'),
                                              duration: const Duration(seconds: 2),
                                              backgroundColor: Colors.green,
                                            ),
                                          );
                                        }
                                      } catch (e) {
                                        print("Erreur lors de l'ajout de l'arrêt: $e");
                                        if (context.mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(
                                              content: Text('Erreur lors de l\'ajout de l\'arrêt'),
                                              duration: const Duration(seconds: 2),
                                              backgroundColor: Colors.red,
                                            ),
                                          );
                                        }
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: Dimensions.paddingSizeDefault,
                                        horizontal: Dimensions.paddingSizeSmall,
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.location_on,
                                            color: Theme.of(context).primaryColor,
                                            size: 20,
                                          ),
                                          const SizedBox(width: Dimensions.paddingSizeSmall),
                                          Expanded(
                                            child: Text(
                                              placeText,
                                              style: textRegular.copyWith(
                                                fontSize: Dimensions.fontSizeDefault,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                        
                        const SizedBox(height: Dimensions.paddingSizeLarge),
                        
                        // Boutons d'action
                        Row(
                          children: [
                            Expanded(
                              child: TextButton(
                                onPressed: () => Navigator.pop(context),
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 16),
                                ),
                                child: Text('Annuler'),
                              ),
                            ),
                            const SizedBox(width: Dimensions.paddingSizeDefault),
                            Expanded(
                              child: ElevatedButton(
                                onPressed: () async {
                                  if (stopController.text.isNotEmpty) {
                                    try {
                                      // Ajouter l'arrêt directement (sans coordonnées précises)
                                      _addStopWithAddress(nextStopType, locationController, stopController.text);
                                      
                                      if (context.mounted) {
                                        Navigator.pop(context);
                                      }
                                      
                                      await Future.delayed(const Duration(milliseconds: 300));
                                      await _triggerAutoCalculate();
                                      
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            content: Text('Arrêt ajouté avec succès'),
                                            duration: const Duration(seconds: 2),
                                            backgroundColor: Colors.green,
                                          ),
                                        );
                                      }
                                    } catch (e) {
                                      print("Erreur: $e");
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            content: Text('Erreur lors de l\'ajout'),
                                            duration: const Duration(seconds: 2),
                                            backgroundColor: Colors.red,
                                          ),
                                        );
                                      }
                                    }
                                  } else {
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text('Veuillez saisir une adresse'),
                                          duration: const Duration(seconds: 2),
                                          backgroundColor: Colors.red,
                                        ),
                                      );
                                    }
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 16),
                                ),
                                child: Text('Ajouter'),
                              ),
                            ),
                          ],
                        ),
                        
                        // Espace supplémentaire
                        SizedBox(height: MediaQuery.of(context).viewInsets.bottom > 0 ? 20 : 0),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
  
  // Gérer la recherche d'adresse
  stopFocusNode.addListener(() {
    if (stopFocusNode.hasFocus && stopController.text.isNotEmpty) {
      _searchAddress(context, stopController.text, locationController, nextStopType);
    }
  });
  
  stopController.addListener(() {
    if (stopController.text.length > 2) {
      _debouncedSearch(context, stopController.text, locationController, nextStopType);
    } else {
      locationController.setSearchResultShowHide(show: false);
    }
  });
  
  // Donner le focus
  Future.delayed(const Duration(milliseconds: 300), () {
    stopFocusNode.requestFocus();
  });
}

// Méthode pour la recherche d'adresse avec debounce
Timer? _searchDebounceTimer;

void _debouncedSearch(BuildContext context, String query, LocationController locationController, LocationType type) {
  _searchDebounceTimer?.cancel();
  _searchDebounceTimer = Timer(const Duration(milliseconds: 500), () {
    _searchAddress(context, query, locationController, type);
  });
}

// Méthode de recherche corrigée avec la bonne signature
void _searchAddress(BuildContext context, String query, LocationController locationController, LocationType type) {
  locationController.locationType = type;
  locationController.searchLocation(
    context,                    // BuildContext
    query,                      // text
    type: type,                 // LocationType
    fromMap: false,             // bool fromMap
  ).then((suggestions) {
    if (suggestions != null) {
      locationController.setSearchResultShowHide(show: true);
      if (mounted) {
        setState(() {});
      }
    }
  });
}

  // Méthode pour obtenir le prochain type d'arrêt disponible
  LocationType _getNextStopType(LocationController locationController) {
    if (!locationController.extraOneRoute) {
      return LocationType.extraOne;
    } else if (!locationController.extraTwoRoute) {
      return LocationType.extraTwo;
    } else {
      return LocationType.extraThree;
    }
  }

  // Méthode pour ajouter un arrêt avec adresse
  void _addStopWithAddress(LocationType type, LocationController locationController, String addressText) {
    switch (type) {
      case LocationType.extraOne:
        locationController.extraOneRoute = true;
        locationController.extraRouteOneController.text = addressText;
        break;
      case LocationType.extraTwo:
        locationController.extraTwoRoute = true;
        locationController.extraRouteTwoController.text = addressText;
        break;
      case LocationType.extraThree:
        locationController.extraThreeRoute = true;
        locationController.extraRouteThreeController.text = addressText;
        break;
      default:
        return;
    }
    
    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Widget du bouton "Supprimer tous les arrêts"
  Widget _buildRemoveAllStopsButton(LocationController locationController) {
    return InkWell(
      onTap: () {
        _showRemoveAllDialog(context, locationController);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: Dimensions.paddingSizeSmall,
          vertical: Dimensions.paddingSizeExtraSmall,
        ),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.1),
          borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
          border: Border.all(color: Colors.red.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.delete_forever,
              color: Colors.red,
              size: 14,
            ),
            const SizedBox(width: Dimensions.paddingSizeExtraSmall),
            Text(
              'supprimer_tout'.tr,
              style: textMedium.copyWith(
                fontSize: Dimensions.fontSizeExtraSmall,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Dialogue de confirmation suppression totale
  void _showRemoveAllDialog(BuildContext context, LocationController locationController) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('supprimer_tous_les_arrêts'.tr),
          content: Text('voulez_vous_supprimer_tous_les_arrêts_intermédiaires'.tr),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('annuler'.tr),
            ),
            TextButton(
              onPressed: () {
                _removeAllStops(locationController);
                Get.back();
                // Déclencher le calcul après suppression
                Future.delayed(const Duration(milliseconds: 100), () {
                  _triggerAutoCalculate();
                });
              },
              child: Text('supprimer'.tr, style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  // Section des arrêts
  Widget _buildStopsSection(LocationController locationController, RideController rideController) {
    final routes = _getRoutesList(locationController);
    if (routes.isEmpty) return const SizedBox.shrink();

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < routes.length; i++)
          Padding(
            padding: EdgeInsets.only(bottom: i < routes.length - 1 ? 0 : 0),
            child: _buildStopItem(
              routes[i],
              locationController,
              rideController,
              i,
              routes.length,
            ),
          ),
      ],
    );
  }

  // Widget d'un arrêt avec autocomplete fonctionnel
  Widget _buildStopItem(
      Map<String, dynamic> route,
      LocationController locationController,
      RideController rideController,
      int index,
      int totalStops,
      ) {
    final type = route['type'];
    final hint = route['hint'];
    final controller = route['controller'];
    final address = route['address'];

    return Container(
      margin: const EdgeInsets.only(top: 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Contrôles à gauche
          Container(
            width: 72,
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                if (index > 0)
                  InkWell(
                    onTap: () {
                      _moveStopUp(index, locationController);
                      // Déclencher le calcul après déplacement
                      Future.delayed(const Duration(milliseconds: 100), () {
                        _triggerAutoCalculate();
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Icon(
                        Icons.arrow_upward,
                        size: 16,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  )
                else
                  const SizedBox(width: 24),

                InkWell(
                  onTap: () {
                    _swapWithDestination(type, locationController);
                    // Déclencher le calcul après échange
                    Future.delayed(const Duration(milliseconds: 100), () {
                      _triggerAutoCalculate();
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Icon(
                      Icons.swap_vert,
                      size: 16,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ),

                if (index < totalStops - 1)
                  InkWell(
                    onTap: () {
                      _moveStopDown(index, locationController);
                      // Déclencher le calcul après déplacement
                      Future.delayed(const Duration(milliseconds: 100), () {
                        _triggerAutoCalculate();
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Icon(
                        Icons.arrow_downward,
                        size: 16,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  )
                else
                  const SizedBox(width: 24),
              ],
            ),
          ),

          // Contenu de l'arrêt avec PickLocationWidget
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: PickLocationWidget(
                      locationType: type,
                      textFieldHint: hint,
                      rideDetails: rideController.rideDetails,
                      focusNode: null,
                      textEditingController: controller,
                      isShowCrossButton: true,
                      locationIconTap: () {
                        RouteHelper.goPageAndHideTextField(
                          context,
                          PickMapScreen(
                            type: type,
                            address: address,
                          ),
                        );
                      },
                      textFieldTap: () {
                        setScrollAndDialogPosition(type, locationController);
                      },
                      onSuggestionSelected: () {
                        _triggerAutoCalculate();
                      },
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      _showDeleteDialog(type, locationController);
                    },
                    icon: Icon(
                      Icons.delete,
                      color: Colors.red,
                      size: 18,
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 36,
                      minHeight: 36,
                    ),
                    tooltip: 'Supprimer cet arrêt',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Dialogue de confirmation suppression d'un arrêt
  void _showDeleteDialog(LocationType type, LocationController locationController) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('supprimer_l_arrêt'.tr),
          content: Text('voulez_vous_supprimer_cet_arrêt'.tr),
          actions: [
            TextButton(
              onPressed: () => Get.back(),
              child: Text('annuler'.tr),
            ),
            TextButton(
              onPressed: () {
                Get.back();
                _removeStop(type, locationController);
                // Déclencher le calcul après suppression
                Future.delayed(const Duration(milliseconds: 100), () {
                  _triggerAutoCalculate();
                });
              },
              child: Text('supprimer'.tr, style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  // Obtenir la liste des arrêts
  List<Map<String, dynamic>> _getRoutesList(LocationController locationController) {
    final List<Map<String, dynamic>> routes = [];

    if (locationController.extraOneRoute) {
      routes.add({
        'type': LocationType.extraOne,
        'hint': 'extra_route_one'.tr,
        'controller': locationController.extraRouteOneController,
        'address': locationController.extraRouteAddress,
      });
    }

    if (locationController.extraTwoRoute) {
      routes.add({
        'type': LocationType.extraTwo,
        'hint': 'extra_route_two'.tr,
        'controller': locationController.extraRouteTwoController,
        'address': locationController.extraRouteTwoAddress,
      });
    }

    if (locationController.extraThreeRoute) {
      routes.add({
        'type': LocationType.extraThree,
        'hint': 'extra_route_three'.tr,
        'controller': locationController.extraRouteThreeController,
        'address': locationController.extraRouteThreeAddress,
      });
    }

    return routes;
  }

  // Ajouter un nouvel arrêt
  void _addNewRoute(LocationController locationController) {
    if (!locationController.extraOneRoute) {
      locationController.extraOneRoute = true;
    } else if (!locationController.extraTwoRoute) {
      locationController.extraTwoRoute = true;
    } else if (!locationController.extraThreeRoute) {
      locationController.extraThreeRoute = true;
    }
    locationController.update();
    setState(() {});
  }

  // Déplacer un arrêt vers le haut
  void _moveStopUp(int index, LocationController locationController) {
    if (index <= 0) return;

    final routes = _getRoutesList(locationController);
    if (routes.length < 2) return;

    final temp = routes[index];
    routes[index] = routes[index - 1];
    routes[index - 1] = temp;

    _updateControllersWithNewOrder(routes, locationController);
  }

  // Déplacer un arrêt vers le bas
  void _moveStopDown(int index, LocationController locationController) {
    final routes = _getRoutesList(locationController);
    if (index >= routes.length - 1) return;

    final temp = routes[index];
    routes[index] = routes[index + 1];
    routes[index + 1] = temp;

    _updateControllersWithNewOrder(routes, locationController);
  }

  // Supprimer un arrêt
  void _removeStop(LocationType type, LocationController locationController) {
    switch (type) {
      case LocationType.extraOne:
        locationController.extraOneRoute = false;
        locationController.extraRouteOneController.clear();
        locationController.extraRouteAddress = null;
        break;
      case LocationType.extraTwo:
        locationController.extraTwoRoute = false;
        locationController.extraRouteTwoController.clear();
        locationController.extraRouteTwoAddress = null;
        break;
      case LocationType.extraThree:
        locationController.extraThreeRoute = false;
        locationController.extraRouteThreeController.clear();
        locationController.extraRouteThreeAddress = null;
        break;
      default:
        return;
    }

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Mettre à jour les contrôleurs avec le nouvel ordre
  void _updateControllersWithNewOrder(
      List<Map<String, dynamic>> routes, LocationController locationController) {
    locationController.extraOneRoute = false;
    locationController.extraTwoRoute = false;
    locationController.extraThreeRoute = false;

    locationController.extraRouteOneController.clear();
    locationController.extraRouteTwoController.clear();
    locationController.extraRouteThreeController.clear();

    locationController.extraRouteAddress = null;
    locationController.extraRouteTwoAddress = null;
    locationController.extraRouteThreeAddress = null;

    for (int i = 0; i < routes.length; i++) {
      final route = routes[i];
      final controller = route['controller'] as TextEditingController;
      final address = route['address'] as Address?;

      String currentText = controller.text;

      if (i == 0) {
        locationController.extraOneRoute = true;
        locationController.extraRouteOneController.text = currentText;
        locationController.extraRouteAddress = address;
      } else if (i == 1) {
        locationController.extraTwoRoute = true;
        locationController.extraRouteTwoController.text = currentText;
        locationController.extraRouteTwoAddress = address;
      } else if (i == 2) {
        locationController.extraThreeRoute = true;
        locationController.extraRouteThreeController.text = currentText;
        locationController.extraRouteThreeAddress = address;
      }
    }

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Échanger un arrêt avec la destination
  void _swapWithDestination(LocationType routeType, LocationController locationController) {
    final tempDestText = locationController.destinationLocationController.text;
    final tempDestAddress = locationController.toAddress;

    switch (routeType) {
      case LocationType.extraOne:
        final tempRouteText = locationController.extraRouteOneController.text;
        final tempRouteAddress = locationController.extraRouteAddress;
        locationController.extraRouteOneController.text = tempDestText;
        locationController.extraRouteAddress = tempDestAddress;
        locationController.destinationLocationController.text = tempRouteText;
        locationController.toAddress = tempRouteAddress;
        break;
      case LocationType.extraTwo:
        final tempRouteText = locationController.extraRouteTwoController.text;
        final tempRouteAddress = locationController.extraRouteTwoAddress;
        locationController.extraRouteTwoController.text = tempDestText;
        locationController.extraRouteTwoAddress = tempDestAddress;
        locationController.destinationLocationController.text = tempRouteText;
        locationController.toAddress = tempRouteAddress;
        break;
      case LocationType.extraThree:
        final tempRouteText = locationController.extraRouteThreeController.text;
        final tempRouteAddress = locationController.extraRouteThreeAddress;
        locationController.extraRouteThreeController.text = tempDestText;
        locationController.extraRouteThreeAddress = tempDestAddress;
        locationController.destinationLocationController.text = tempRouteText;
        locationController.toAddress = tempRouteAddress;
        break;
      default:
        return;
    }

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Supprimer tous les arrêts
  void _removeAllStops(LocationController locationController) {
    locationController.extraRouteOneController.clear();
    locationController.extraRouteTwoController.clear();
    locationController.extraRouteThreeController.clear();

    locationController.extraRouteAddress = null;
    locationController.extraRouteTwoAddress = null;
    locationController.extraRouteThreeAddress = null;

    locationController.extraOneRoute = false;
    locationController.extraTwoRoute = false;
    locationController.extraThreeRoute = false;

    locationController.update();
    Get.find<RideController>().update();
    setState(() {});
  }

  // Méthode pour positionner la boîte de dialogue d'autocomplete
  void setScrollAndDialogPosition(LocationType locationType, LocationController locationController) {
    locationController.setSearchResultShowHide(show: true);

    // Positionner la boîte de dialogue selon le type de champ
    if (locationType == LocationType.from) {
      dialogTopPosition = 180;
    } else if (locationType == LocationType.extraOne) {
      dialogTopPosition = locationController.extraTwoRoute ? 280 : 320;
    } else if (locationType == LocationType.extraTwo) {
      dialogTopPosition = 360;
    } else if (locationType == LocationType.extraThree) {
      dialogTopPosition = 400;
    } else if (locationType == LocationType.to) {
      dialogTopPosition = 440;
    }

    setState(() {});
  }

  void _sendFindRiderRequest(RideController rideController){
    rideController.submitRideRequest(rideController.noteController.text, false).then((value) {
      if (value.statusCode == 200) {
        Get.find<AuthController>().saveFindingRideCreatedTime();
        rideController.updateRideCurrentState(RideState.findingRider);
        Get.find<MapController>().initializeData();
        Get.find<MapController>().setOwnCurrentLocation(
            LatLng(
                Get.find<LocationController>().fromAddress?.latitude ?? 0,
                Get.find<LocationController>().fromAddress?.longitude ?? 0
            )
        );
        Get.find<MapController>().notifyMapController();
      }
    });
  }
}

class _LocationFromToWidget extends StatelessWidget {
  const _LocationFromToWidget();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        Dimensions.paddingSizeSmall,
        Dimensions.paddingSizeDefault,
        0,
        0,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: Dimensions.iconSizeLarge,
            child: Image.asset(
              Images.currentLocation,
              color: Theme.of(context).textTheme.bodyMedium!.color,
            ),
          ),
          Container(
            height: 40,
            width: 10,
            child: CustomDivider(
              height: 4,
              dashWidth: 0.8,
              axis: Axis.vertical,
              color: Theme.of(context).textTheme.bodyMedium!.color!.withValues(alpha: 0.5),
            ),
          ),
          SizedBox(
            width: Dimensions.iconSizeMedium,
            child: Transform(
              alignment: Alignment.center,
              transform: Get.find<LocalizationController>().isLtr
                  ? Matrix4.rotationY(0)
                  : Matrix4.rotationY(math.pi),
              child: Image.asset(
                Images.activityDirection,
                color: Theme.of(context).textTheme.bodyMedium!.color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}