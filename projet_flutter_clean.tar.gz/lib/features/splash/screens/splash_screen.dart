

// import 'dart:async';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:get/get.dart';
// import 'package:ride_sharing_user_app/helper/login_helper.dart';
// import 'package:ride_sharing_user_app/util/images.dart';
// import 'package:ride_sharing_user_app/features/splash/controllers/config_controller.dart';

// class SplashScreen extends StatefulWidget {
//   final Map<String, dynamic>? notificationData;
//   final String? userName;
//   const SplashScreen({super.key, this.notificationData, this.userName});

//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen>
//     with SingleTickerProviderStateMixin {
//   StreamSubscription<List<ConnectivityResult>>? _onConnectivityChanged;
//   late AnimationController _controller;
  
//   // Animations principales - simplifiées mais élégantes
//   late Animation<double> _fadeAnimation;
//   late Animation<double> _scaleAnimation;
//   late Animation<double> _rotationAnimation;
  
//   // Animations pour les éléments de texte
//   late Animation<double> _textFadeAnimation;
//   late Animation<Offset> _slideAnimation;
  
//   // Animation pour l'effet de pulsation
//   late Animation<double> _pulseAnimation;

//   @override
//   void initState() {
//     super.initState();

//     // Animation controller
//     _controller = AnimationController(
//       vsync: this,
//       duration: const Duration(milliseconds: 2800),
//     );

//     // Animation de fondu
//     _fadeAnimation = Tween<double>(
//       begin: 0.0,
//       end: 1.0,
//     ).animate(CurvedAnimation(
//       parent: _controller,
//       curve: const Interval(0.0, 0.4, curve: Curves.easeIn),
//     ));

//     // Animation d'échelle simplifiée - SANS TweenSequence
//     _scaleAnimation = Tween<double>(
//       begin: 0.3,
//       end: 1.0,
//     ).animate(CurvedAnimation(
//       parent: _controller,
//       curve: const Interval(0.0, 0.7, curve: Curves.elasticOut),
//     ));

//     // Animation de rotation subtile
//     _rotationAnimation = Tween<double>(
//       begin: -0.15,
//       end: 0.0,
//     ).animate(CurvedAnimation(
//       parent: _controller,
//       curve: const Interval(0.2, 0.6, curve: Curves.easeOutCubic),
//     ));

//     // Animation de pulsation pour la fin
//     _pulseAnimation = Tween<double>(
//       begin: 1.0,
//       end: 1.1,
//     ).animate(CurvedAnimation(
//       parent: _controller,
//       curve: const Interval(0.7, 0.9, curve: Curves.easeInOut),
//     ));

//     // Animation pour le texte principal
//     _textFadeAnimation = Tween<double>(
//       begin: 0.0,
//       end: 1.0,
//     ).animate(CurvedAnimation(
//       parent: _controller,
//       curve: const Interval(0.5, 0.8, curve: Curves.easeIn),
//     ));

//     // Animation de glissement pour le texte
//     _slideAnimation = Tween<Offset>(
//       begin: const Offset(0, 0.5),
//       end: Offset.zero,
//     ).animate(CurvedAnimation(
//       parent: _controller,
//       curve: const Interval(0.5, 0.9, curve: Curves.easeOutBack),
//     ));

//     // Démarrer l'animation
//     _controller.forward();

//     // Initialiser les données
//     Get.find<ConfigController>().initSharedData();
//     _checkConnectivity();

//     // Navigation automatique après l'animation
//     Timer(const Duration(milliseconds: 3200), () {
//       if (mounted) {
//         LoginHelper().handleIncomingLinks(widget.notificationData, widget.userName);
//       }
//     });
//   }

//   void _checkConnectivity() {
//     bool isFirst = true;
//     _onConnectivityChanged = Connectivity().onConnectivityChanged.listen(
//       (List<ConnectivityResult> result) {
//         if (!mounted) return;
        
//         bool isConnected = result.contains(ConnectivityResult.wifi) ||
//             result.contains(ConnectivityResult.mobile);

//         if (!isFirst || !isConnected) {
//           ScaffoldMessenger.of(context).removeCurrentSnackBar();
//           ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//             backgroundColor: isConnected ? Colors.green : Colors.red,
//             duration: Duration(milliseconds: isConnected ? 1000 : 3000),
//             content: Text(
//               isConnected ? 'connected'.tr : 'no_connection'.tr,
//               textAlign: TextAlign.center,
//             ),
//           ));

//           if (isConnected && !isFirst && mounted) {
//             LoginHelper().handleIncomingLinks(widget.notificationData, widget.userName);
//           }
//         }
//         isFirst = false;
//       },
//     );
//   }

//   @override
//   void dispose() {
//     _controller.dispose();
//     _onConnectivityChanged?.cancel();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             begin: Alignment.topCenter,
//             end: Alignment.bottomCenter,
//             colors: [
//               Theme.of(context).primaryColor,
//               Theme.of(context).primaryColor.withOpacity(0.8),
//               Theme.of(context).primaryColor.withOpacity(0.6),
//             ],
//             stops: const [0.0, 0.6, 1.0],
//           ),
//         ),
//         child: Stack(
//           children: [
//             // Effet de cercles décoratifs
//             ..._buildDecorativeCircles(),
            
//             // Contenu principal
//             Center(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   // Logo avec animations
//                   AnimatedBuilder(
//                     animation: _controller,
//                     builder: (context, child) {
//                       // Appliquer la pulsation seulement à la fin
//                       double scale = _scaleAnimation.value;
//                       if (_controller.value >= 0.7) {
//                         scale *= (1.0 + (_pulseAnimation.value - 1.0) * 
//                                ((_controller.value - 0.7) / 0.3));
//                       }
                      
//                       return Transform.rotate(
//                         angle: _rotationAnimation.value * 3.14159,
//                         child: Transform.scale(
//                           scale: scale,
//                           child: Opacity(
//                             opacity: _fadeAnimation.value,
//                             child: Container(
//                               padding: const EdgeInsets.all(20),
//                               decoration: BoxDecoration(
//                                 color: Colors.white.withOpacity(0.15),
//                                 borderRadius: BorderRadius.circular(30),
//                                 boxShadow: [
//                                   BoxShadow(
//                                     color: Colors.black.withOpacity(0.2),
//                                     blurRadius: 30,
//                                     spreadRadius: 5,
//                                     offset: const Offset(0, 10),
//                                   ),
//                                 ],
//                                 border: Border.all(
//                                   color: Colors.white.withOpacity(0.3),
//                                   width: 2,
//                                 ),
//                               ),
//                               child: SvgPicture.asset(
//                                 Images.splashSvgLogo,
//                                 width: 120,
//                                 height: 120,
//                                 colorFilter: const ColorFilter.mode(
//                                   Colors.white,
//                                   BlendMode.srcIn,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       );
//                     },
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   List<Widget> _buildDecorativeCircles() {
//     return List.generate(3, (index) {
//       return AnimatedBuilder(
//         animation: _controller,
//         builder: (context, child) {
//           double progress = (_controller.value - 0.1 * (index + 1))
//               .clamp(0.0, 0.8) / 0.8;
          
//           if (_controller.value < 0.1 * (index + 1)) {
//             return const SizedBox.shrink();
//           }
          
//           return Positioned(
//             left: 50.0 + (index * 100.0),
//             top: 100.0 + (index * 150.0),
//             child: Opacity(
//               opacity: (1.0 - progress) * 0.3,
//               child: Transform.scale(
//                 scale: 1.0 + progress * 3,
//                 child: Container(
//                   width: 30.0 + (index * 20.0),
//                   height: 30.0 + (index * 20.0),
//                   decoration: BoxDecoration(
//                     shape: BoxShape.circle,
//                     color: Colors.white.withOpacity(0.2),
//                     border: Border.all(
//                       color: Colors.white.withOpacity(0.1),
//                       width: 1,
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           );
//         },
//       );
//     });
//   }
// }

import 'dart:async';
import 'dart:math';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:ride_sharing_user_app/helper/login_helper.dart';
import 'package:ride_sharing_user_app/util/images.dart';
import 'package:ride_sharing_user_app/features/splash/controllers/config_controller.dart';

class SplashScreen extends StatefulWidget {
  final Map<String, dynamic>? notificationData;
  final String? userName;
  const SplashScreen({super.key, this.notificationData, this.userName});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {  // CHANGÉ: SingleTickerProviderStateMixin -> TickerProviderStateMixin
  StreamSubscription<List<ConnectivityResult>>? _onConnectivityChanged;
  late AnimationController _controller;
  late AnimationController _particlesController;
  
  // Animations principales
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _rotationAnimation;
  late Animation<double> _pulseAnimation;

  // Particules
  final List<Particle> _particles = [];
  final Random _random = Random();

  @override
  void initState() {
    super.initState();

    // Animation controller principal
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    // Controller pour les particules
    _particlesController = AnimationController(
      vsync: this,
     // duration: const Duration(seconds: 10),
     duration: const Duration(milliseconds: 500),
    )..repeat();

    // Initialiser les particules
    _initializeParticles();

    // Animation de fondu
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.4, curve: Curves.easeIn),
    ));

    // Animation d'échelle
    _scaleAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.7, curve: Curves.elasticOut),
    ));

    // Animation de rotation subtile
    _rotationAnimation = Tween<double>(
      begin: -0.15,
      end: 0.0,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.2, 0.6, curve: Curves.easeOutCubic),
    ));

    // Animation de pulsation
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.7, 0.9, curve: Curves.easeInOut),
    ));

    // Démarrer l'animation principale
    _controller.forward();

    // Initialiser les données
    Get.find<ConfigController>().initSharedData();

    // Navigation automatique après l'animation
    Timer(const Duration(milliseconds: 500), () {
      if (mounted) {
        LoginHelper().handleIncomingLinks(widget.notificationData, widget.userName);
      }
    });

    // Ajouter un listener pour mettre à jour les particules
    _particlesController.addListener(() {
      if (mounted) {
        setState(() {
          for (var particle in _particles) {
            particle.update();
          }
        });
      }
    });

    // Attendre que le widget soit construit pour vérifier la connectivité
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkConnectivity();
    });
  }

  void _initializeParticles() {
    for (int i = 0; i < 50; i++) {
      _particles.add(Particle(random: _random));
    }
  }

  void _checkConnectivity() {
    bool isFirst = true;
    _onConnectivityChanged = Connectivity().onConnectivityChanged.listen(
      (List<ConnectivityResult> result) {
        if (!mounted) return;
        
        bool isConnected = result.contains(ConnectivityResult.wifi) ||
            result.contains(ConnectivityResult.mobile);

        if (!isFirst || !isConnected) {
          ScaffoldMessenger.of(context).removeCurrentSnackBar();
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            backgroundColor: isConnected ? Colors.green : Colors.red,
            duration: Duration(milliseconds: isConnected ? 1000 : 3000),
            content: Text(
              isConnected ? 'connected'.tr : 'no_connection'.tr,
              textAlign: TextAlign.center,
            ),
          ));

          if (isConnected && !isFirst && mounted) {
            LoginHelper().handleIncomingLinks(widget.notificationData, widget.userName);
          }
        }
        isFirst = false;
      },
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _particlesController.dispose();
    _onConnectivityChanged?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor.withOpacity(0.8),
              Theme.of(context).primaryColor.withOpacity(0.6),
            ],
            stops: const [0.0, 0.6, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // Particules en arrière-plan
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _particlesController,
                builder: (context, child) {
                  return CustomPaint(
                    painter: ParticlePainter(_particles),
                    size: Size.infinite,
                  );
                },
              ),
            ),

            // Cercles décoratifs
            ..._buildDecorativeCircles(),
            
            // Logo principal
            Center(
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  double scale = _scaleAnimation.value;
                  if (_controller.value >= 0.7) {
                    scale *= (1.0 + (_pulseAnimation.value - 1.0) * 
                           ((_controller.value - 0.7) / 0.3));
                  }
                  
                  return Transform.rotate(
                    angle: _rotationAnimation.value * 3.14159,
                    child: Transform.scale(
                      scale: scale,
                      child: Opacity(
                        opacity: _fadeAnimation.value,
                        child: SvgPicture.asset(
                          Images.splashSvgLogo,
                          width: 150,
                          height: 150,
                          colorFilter: const ColorFilter.mode(
                            Colors.white,
                            BlendMode.srcIn,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildDecorativeCircles() {
    return List.generate(3, (index) {
      return AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          double progress = (_controller.value - 0.1 * (index + 1))
              .clamp(0.0, 0.8) / 0.8;
          
          if (_controller.value < 0.1 * (index + 1)) {
            return const SizedBox.shrink();
          }
          
          return Positioned(
            left: 50.0 + (index * 100.0),
            top: 100.0 + (index * 150.0),
            child: Opacity(
              opacity: (1.0 - progress) * 0.3,
              child: Transform.scale(
                scale: 1.0 + progress * 3,
                child: Container(
                  width: 30.0 + (index * 20.0),
                  height: 30.0 + (index * 20.0),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.2),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.1),
                      width: 1,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      );
    });
  }
}

// Classe pour représenter une particule
class Particle {
  double x;
  double y;
  double size;
  double speed;
  double opacity;
  double angle;
  final Random random;

  Particle({required this.random}) : 
    x = 0,
    y = 0,
    size = 0,
    speed = 0,
    opacity = 0,
    angle = 0 {
    _reset();
  }

  void _reset() {
    x = random.nextDouble() * 1.2 - 0.1; // -0.1 à 1.1
    y = random.nextDouble() * 1.2 - 0.1;
    size = 1.0 + random.nextDouble() * 3.0;
    speed = 0.001 + random.nextDouble() * 0.005;
    opacity = 0.1 + random.nextDouble() * 0.3;
    angle = random.nextDouble() * 2 * pi;
  }

  void update() {
    // Mouvement en cercle lent
    angle += 0.001;
    
    // Petit mouvement aléatoire
    x += sin(angle) * 0.0005;
    y += cos(angle) * 0.0005;

    // Réinitialiser si la particule sort de l'écran
    if (x < -0.1 || x > 1.1 || y < -0.1 || y > 1.1) {
      _reset();
    }
  }
}

// Painter pour dessiner les particules
class ParticlePainter extends CustomPainter {
  final List<Particle> particles;

  ParticlePainter(this.particles);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill;

    for (var particle in particles) {
      paint.color = Colors.white.withOpacity(particle.opacity);
      canvas.drawCircle(
        Offset(particle.x * size.width, particle.y * size.height),
        particle.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant ParticlePainter oldDelegate) {
    return true;
  }
}