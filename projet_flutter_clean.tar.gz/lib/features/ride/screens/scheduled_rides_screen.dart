// // lib/features/ride/screens/scheduled_rides_screen.dart

// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:ride_sharing_user_app/common_widgets/app_bar_widget.dart';
// import 'package:ride_sharing_user_app/features/ride/controllers/ride_controller.dart';
// import 'package:ride_sharing_user_app/helper/date_converter.dart';
// import 'package:ride_sharing_user_app/util/dimensions.dart';
// import 'package:ride_sharing_user_app/util/styles.dart';

// class ScheduledRidesScreen extends StatefulWidget {
//   const ScheduledRidesScreen({super.key});

//   @override
//   State<ScheduledRidesScreen> createState() => _ScheduledRidesScreenState();
// }

// class _ScheduledRidesScreenState extends State<ScheduledRidesScreen> {
//   @override
//   void initState() {
//     super.initState();
//     // Charger automatiquement les trajets à l'ouverture
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       Get.find<RideController>().getScheduledRideList();
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBarWidget(
//         title: 'Mes trajets programmés',
//         centerTitle: true,
//       ),
//       body: const ScheduledRidesManager(),
//       floatingActionButton: FloatingActionButton.extended(
//         onPressed: () {
//           // Naviguer vers l'écran de création de trajet programmé
//           Get.toNamed('/set-destination', arguments: {'rideType': 'scheduled'});
//         },
//         icon: const Icon(Icons.add),
//         label: const Text('Nouveau trajet'),
//       ),
//     );
//   }
// }

// // Widget de gestion des trajets programmés
// class ScheduledRidesManager extends StatelessWidget {
//   const ScheduledRidesManager({super.key});

//   String _formatDate(String? dateTime) {
//     if (dateTime == null) return 'Date non spécifiée';
//     try {
//       DateTime date = DateTime.parse(dateTime);
//       return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year} à ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
//     } catch (e) {
//       return dateTime;
//     }
//   }

//   void _showDeleteDialog(BuildContext context, String rideId) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('Supprimer le trajet'),
//           content: Text('Voulez-vous vraiment supprimer ce trajet programmé ?'),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.pop(context),
//               child: Text('Annuler'),
//             ),
//             TextButton(
//               onPressed: () {
//                 Navigator.pop(context);
//                 Get.find<RideController>().deleteScheduledRide(rideId);
//               },
//               child: Text(
//                 'Supprimer',
//                 style: TextStyle(color: Colors.red),
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return GetBuilder<RideController>(
//       builder: (controller) {
//         if (controller.isLoading) {
//           return const Center(child: CircularProgressIndicator());
//         }

//         return RefreshIndicator(
//           onRefresh: () => controller.getScheduledRideList(),
//           child: controller.scheduledRides.isEmpty
//               ? _buildEmptyState()
//               : ListView.builder(
//                   padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
//                   itemCount: controller.scheduledRides.length,
//                   itemBuilder: (context, index) {
//                     final ride = controller.scheduledRides[index];
//                     return _buildRideCard(ride, context, controller);
//                   },
//                 ),
//         );
//       },
//     );
//   }

//   Widget _buildEmptyState() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(
//             Icons.schedule_send_outlined,
//             size: 80,
//             color: Colors.grey[400],
//           ),
//           const SizedBox(height: Dimensions.paddingSizeDefault),
//           Text(
//             'Aucun trajet programmé',
//             style: textBold.copyWith(
//               fontSize: Dimensions.fontSizeLarge,
//             ),
//           ),
//           const SizedBox(height: Dimensions.paddingSizeSmall),
//           Text(
//             'Vous n\'avez pas encore de trajets programmés',
//             style: textRegular.copyWith(
//               color: Colors.grey[600],
//             ),
//             textAlign: TextAlign.center,
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildRideCard(dynamic ride, BuildContext context, RideController controller) {
//     return Container(
//       margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeDefault),
//       padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
//       decoration: BoxDecoration(
//         color: Theme.of(context).cardColor,
//         borderRadius: BorderRadius.circular(Dimensions.paddingSizeDefault),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.grey.withOpacity(0.1),
//             blurRadius: 5,
//             offset: const Offset(0, 2),
//           ),
//         ],
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   color: Theme.of(context).primaryColor.withOpacity(0.1),
//                   borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//                 ),
//                 child: Icon(
//                   Icons.calendar_today,
//                   color: Theme.of(context).primaryColor,
//                   size: 16,
//                 ),
//               ),
//               const SizedBox(width: Dimensions.paddingSizeSmall),
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       _formatDate(ride.scheduledAt),
//                       style: textSemiBold,
//                     ),
//                     Text(
//                       ride.pickupAddress?.address ?? 'Adresse non spécifiée',
//                       style: textRegular.copyWith(
//                         fontSize: Dimensions.fontSizeSmall,
//                         color: Colors.grey[600],
//                       ),
//                       maxLines: 1,
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                   ],
//                 ),
//               ),
//               _buildStatusBadge(ride.status),
//             ],
//           ),
//           const SizedBox(height: Dimensions.paddingSizeDefault),
//           const Divider(height: 1),
//           const SizedBox(height: Dimensions.paddingSizeDefault),
//           Row(
//             children: [
//               Expanded(
//                 child: _buildActionButton(
//                   onTap: () {
//                     // Naviguer vers l'écran de modification
//                     Get.toNamed('/set-destination', arguments: {
//                       'ride': ride,
//                       'rideType': 'scheduled',
//                       'isEditing': true,
//                     });
//                   },
//                   icon: Icons.edit,
//                   label: 'Modifier',
//                   color: Colors.blue,
//                 ),
//               ),
//               const SizedBox(width: Dimensions.paddingSizeSmall),
//               Expanded(
//                 child: _buildActionButton(
//                   onTap: () => _showDeleteDialog(context, ride.id!),
//                   icon: Icons.delete,
//                   label: 'Supprimer',
//                   color: Colors.red,
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }

//   Widget _buildStatusBadge(String? status) {
//     Color color;
//     String label;
    
//     switch (status?.toLowerCase()) {
//       case 'pending':
//         color = Colors.orange;
//         label = 'En attente';
//         break;
//       case 'confirmed':
//         color = Colors.green;
//         label = 'Confirmé';
//         break;
//       case 'cancelled':
//         color = Colors.red;
//         label = 'Annulé';
//         break;
//       default:
//         color = Colors.grey;
//         label = status ?? 'Inconnu';
//     }

//     return Container(
//       padding: const EdgeInsets.symmetric(
//         horizontal: Dimensions.paddingSizeSmall,
//         vertical: 4,
//       ),
//       decoration: BoxDecoration(
//         color: color.withOpacity(0.1),
//         borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//         border: Border.all(color: color.withOpacity(0.3)),
//       ),
//       child: Text(
//         label,
//         style: textMedium.copyWith(
//           fontSize: Dimensions.fontSizeExtraSmall,
//           color: color,
//         ),
//       ),
//     );
//   }

//   Widget _buildActionButton({
//     required VoidCallback onTap,
//     required IconData icon,
//     required String label,
//     required Color color,
//   }) {
//     return InkWell(
//       onTap: onTap,
//       child: Container(
//         padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
//         decoration: BoxDecoration(
//           color: color.withOpacity(0.1),
//           borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
//           border: Border.all(color: color.withOpacity(0.3)),
//         ),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(icon, size: 16, color: color),
//             const SizedBox(width: 4),
//             Text(
//               label,
//               style: textMedium.copyWith(
//                 fontSize: Dimensions.fontSizeSmall,
//                 color: color,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }



// lib/features/ride/screens/scheduled_rides_screen.dart

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ride_sharing_user_app/common_widgets/app_bar_widget.dart';
import 'package:ride_sharing_user_app/common_widgets/body_widget.dart';
import 'package:ride_sharing_user_app/features/home/widgets/banner_shimmer.dart';
import 'package:ride_sharing_user_app/features/ride/controllers/ride_controller.dart';
import 'package:ride_sharing_user_app/features/set_destination/screens/set_destination_screen.dart';
import 'package:ride_sharing_user_app/helper/date_converter.dart';
import 'package:ride_sharing_user_app/util/dimensions.dart';
import 'package:ride_sharing_user_app/util/images.dart';
import 'package:ride_sharing_user_app/util/styles.dart';

class ScheduledRidesScreen extends StatefulWidget {
  const ScheduledRidesScreen({super.key});

  @override
  State<ScheduledRidesScreen> createState() => _ScheduledRidesScreenState();
}

class _ScheduledRidesScreenState extends State<ScheduledRidesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<RideController>().getScheduledRideList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Scaffold(
        body: BodyWidget(
          appBar: AppBarWidget(
            title: 'Mes trajets programmés'.tr,
            showBackButton: true,
            centerTitle: true,
          ),
          body: const ScheduledRidesManager(),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
           // Get.toNamed('/set-destination', arguments: {'rideType': 'scheduled'});
            Get.to(() => const SetDestinationScreen(rideType: RideType.scheduleRide));
          },
          icon: const Icon(Icons.add),
          label: Text('Nouveau trajet'.tr),
          backgroundColor: Theme.of(context).primaryColor,
        ),
      ),
    );
  }
}

class ScheduledRidesManager extends StatelessWidget {
  const ScheduledRidesManager({super.key});

  String _formatDate(String? dateTime) {
    if (dateTime == null) return 'Date non spécifiée'.tr;
    try {
      DateTime date = DateTime.parse(dateTime);
      return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year} à ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return dateTime;
    }
  }

  void _showDeleteDialog(BuildContext context, String rideId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Supprimer le trajet'.tr),
          content: Text('Voulez-vous vraiment supprimer ce trajet programmé ?'.tr),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Annuler'.tr),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Get.find<RideController>().deleteScheduledRide(rideId);
              },
              child: Text(
                'Supprimer'.tr,
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RideController>(
      builder: (controller) {
        return Padding(
          padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header avec statistiques ou info
              Container(
                width: Get.width,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
                ),
                child: Column(
                  spacing: Dimensions.paddingSizeSmall,
                  children: [
                    const SizedBox(height: Dimensions.paddingSizeSmall),
                    
                    Image.asset(
                      Images.calenderIcon, // Vous devrez ajouter cette image
                      height: 80,
                      width: 80,
                      errorBuilder: (context, error, stackTrace) => Icon(
                        Icons.schedule,
                        size: 80,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                    
                    Text(
                      'Vos trajets programmés'.tr,
                      style: textSemiBold.copyWith(fontSize: 16),
                    ),
                    
                    Padding(
                      padding: const EdgeInsets.only(
                        bottom: Dimensions.paddingSizeSmall,
                        left: Dimensions.paddingSizeSmall,
                        right: Dimensions.paddingSizeSmall,
                      ),
                      child: Text(
                        controller.scheduledRides.isEmpty
                            ? 'Vous n\'avez aucun trajet programmé pour le moment'.tr
                            : 'Vous avez ${controller.scheduledRides.length} trajet(s) programmé(s)'.tr,
                        style: textRegular.copyWith(fontSize: 10),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: Dimensions.paddingSizeDefault),

              // Titre de la liste
              if (controller.scheduledRides.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
                  child: Text(
                    'Liste des trajets'.tr,
                    style: textSemiBold,
                  ),
                ),

              // Liste des trajets ou état vide
              Expanded(
                child: controller.isLoading
                  ? const BannerShimmer()
                  : controller.scheduledRides.isEmpty
                      ? _buildEmptyState()
                      : RefreshIndicator(
                          onRefresh: () => controller.getScheduledRideList(),
                          child: ListView.separated(
                            padding: EdgeInsets.zero,
                            itemCount: controller.scheduledRides.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index) {
                              final ride = controller.scheduledRides[index];
                              return _buildRideCard(ride, context, controller);
                            },
                            separatorBuilder: (context, index) {
                              return SizedBox(height: Dimensions.paddingSizeSmall);
                            },
                          ),
                        ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.schedule_send_outlined,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: Dimensions.paddingSizeDefault),
          Text(
            'Aucun trajet programmé'.tr,
            style: textBold.copyWith(
              fontSize: Dimensions.fontSizeLarge,
            ),
          ),
          const SizedBox(height: Dimensions.paddingSizeSmall),
          Text(
            'Vous n\'avez pas encore de trajets programmés.\nAppuyez sur le bouton + pour en créer un.'.tr,
            style: textRegular.copyWith(
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRideCard(dynamic ride, BuildContext context, RideController controller) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
        border: Border.all(color: Theme.of(context).hintColor.withValues(alpha: 0.2)),
      ),
      child: ExpansionTile(
        collapsedIconColor: Theme.of(context).textTheme.bodyMedium!.color,
        iconColor: Theme.of(context).textTheme.bodyMedium!.color,
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
          ),
          child: Icon(
            Icons.calendar_today,
            color: Theme.of(context).primaryColor,
            size: 16,
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _formatDate(ride.scheduledAt),
              style: textSemiBold.copyWith(fontSize: Dimensions.fontSizeDefault),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: Text(
                    ride.pickupAddress?.address ?? 'Adresse de départ non spécifiée'.tr,
                    style: textRegular.copyWith(
                      fontSize: Dimensions.fontSizeExtraSmall,
                      color: Colors.grey[600],
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: Dimensions.paddingSizeSmall),
                _buildStatusBadge(ride.status),
              ],
            ),
          ],
        ),
        shape: Border(),
        expandedAlignment: Alignment.centerLeft,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(
              vertical: Dimensions.paddingSizeSmall,
              horizontal: Dimensions.paddingSizeExtraLarge,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Informations détaillées
                _buildDetailRow(
                  icon: Icons.location_on,
                  label: 'Adresse:'.tr,
                  value: ride.pickupAddress?.address ?? 'Adresse de départ non spécifiée'.tr,
                ),
              const SizedBox(height: Dimensions.paddingSizeSmall),

                _buildDetailRow(
                  icon: Icons.location_on,
                  label: 'Destination:'.tr,
                  value: ride.destinationAddress?.address ?? 'Non spécifiée'.tr,
                ),
                
                const SizedBox(height: Dimensions.paddingSizeSmall),
                
                _buildDetailRow(
                  icon: Icons.attach_money,
                  label: 'Prix estimé:'.tr,
                  value: '${ride.estimatedFare?.toStringAsFixed(0) ?? '0'} FCFA',
                ),
                
                const SizedBox(height: Dimensions.paddingSizeSmall),
                
                _buildDetailRow(
                  icon: Icons.speed,
                  label: 'Distance:'.tr,
                  value: '${ride.estimatedDistance ?? '0'} km',
                ),
                
                const SizedBox(height: Dimensions.paddingSizeSmall),
                
                _buildDetailRow(
                  icon: Icons.timer,
                  label: 'Durée:'.tr,
                  value: '${ride.estimatedDuration ?? '0'} min',
                ),
                
                if (ride.vehicleCategoryName != null) ...[
                  const SizedBox(height: Dimensions.paddingSizeSmall),
                  _buildDetailRow(
                    icon: Icons.directions_car,
                    label: 'Véhicule:'.tr,
                    value: ride.vehicleCategoryName!,
                  ),
                ],
                
                const SizedBox(height: Dimensions.paddingSizeDefault),
                
              //  Boutons d'action
                Row(
                  children: [
                    // Expanded(
                    //   child: _buildActionButton(
                    //     onTap: () {
                    //       Get.toNamed('/set-destination', arguments: {
                    //         'ride': ride,
                    //         'rideType': 'scheduled',
                    //         'isEditing': true,
                    //       });
                           
                    //     },
                    //     icon: Icons.edit,
                    //     label: 'Modifier'.tr,
                    //     color: Colors.blue,
                    //   ),
                    // ),
                    // const SizedBox(width: Dimensions.paddingSizeSmall),
                    Expanded(
                      child: _buildActionButton(
                        onTap: () => _showDeleteDialog(context, ride.id!),
                        icon: Icons.delete,
                        label: 'Supprimer'.tr,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 16, color: Colors.grey[600]),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Expanded(
          child: RichText(
            text: TextSpan(
              style: textRegular.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: Colors.grey[600],
              ),
              children: [
                TextSpan(
                  text: '$label ',
                  style: textMedium.copyWith(
                    color: Colors.grey[800],
                  ),
                ),
                TextSpan(
                  text: value,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatusBadge(String? status) {
    Color color;
    String label;
    
    switch (status?.toLowerCase()) {
      case 'pending':
        color = Colors.orange;
        label = 'En attente'.tr;
        break;
      case 'confirmed':
        color = Colors.green;
        label = 'Confirmé'.tr;
        break;
      case 'cancelled':
        color = Colors.red;
        label = 'Annulé'.tr;
        break;
      case 'completed':
        color = Colors.blue;
        label = 'Terminé'.tr;
        break;
      default:
        color = Colors.grey;
        label = status ?? 'Inconnu'.tr;
    }

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: Dimensions.paddingSizeSmall,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: textMedium.copyWith(
          fontSize: Dimensions.fontSizeExtraSmall,
          color: color,
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required VoidCallback onTap,
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: Dimensions.paddingSizeSmall),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(Dimensions.paddingSizeSmall),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 4),
            Text(
              label,
              style: textMedium.copyWith(
                fontSize: Dimensions.fontSizeSmall,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}