// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:get/get.dart';
// import 'package:ride_sharing_user_app/helper/svg_image_helper.dart';
// import 'package:ride_sharing_user_app/util/dimensions.dart';
// import 'package:ride_sharing_user_app/util/styles.dart';


// class PagerContent extends StatelessWidget {
//   const PagerContent({super.key, required this.image, required this.text1, required this.text2, required this.text3, required this.text4, required this.index});
//   final String image;
//   final String text1;
//   final String text2;
//   final String text3;
//   final String text4;
//   final int index;

//   @override
//   Widget build(BuildContext context) {
//     if(index != 3) {
//       return Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const Spacer(),

//           SizedBox(
//             height: MediaQuery.of(context).size.height * 0.25,
//             child: Padding(
//               padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraLarge),
//               child: RichText(text: TextSpan(
//                   children: [
//                     TextSpan(text: text1, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).primaryColor)),
//                     TextSpan(text: text2, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).textTheme.bodyMedium?.color)),
//                     TextSpan(text: text3, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).primaryColor)),
//                     TextSpan(text: text4, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).textTheme.bodyMedium?.color)),
//                   ]
//               ))
//             ),
//           ),

//           const Spacer(),

//           Padding(
//             padding: EdgeInsets.only(left: index == 1 ? Dimensions.paddingSizeSmall : 0),
//             child: FutureBuilder<String>(
//                 future: loadSvgAndChangeColors(image, Theme.of(context).primaryColor),
//                 builder: (context, snapshot){
//                   if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
//                     return SvgPicture.string(
//                       snapshot.data!, width: Get.width,
//                     );
//                   }
//                   return SvgPicture.asset(image, width: Get.width);
//                 }
//             ),
//           ),

//           SizedBox(height: MediaQuery.of(context).size.height * 0.05)
//         ],
//       );
//     }

//      return Column(
//        crossAxisAlignment: CrossAxisAlignment.start,
//        children: [
//          SizedBox(height: Get.height * 0.03),

//          FutureBuilder<String>(
//              future: loadSvgAndChangeColors(image, Theme.of(context).primaryColor),
//              builder: (context, snapshot){
//                if (snapshot.connectionState == ConnectionState.done && snapshot.hasData) {
//                  return SvgPicture.string(
//                      snapshot.data!
//                  );
//                }
//                return const SizedBox(height: 150, child: Center(child: CircularProgressIndicator()));
//              }
//          ),
//          const SizedBox(height: Dimensions.paddingSizeExtraLarge),

//          Padding(
//            padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraLarge),
//            child: RichText(text: TextSpan(
//                children: [
//                  TextSpan(text: text1, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).primaryColor)),
//                  TextSpan(text: text2, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).textTheme.bodyMedium?.color)),
//                  TextSpan(text: text3, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).primaryColor)),
//                  TextSpan(text: text4, style: textMedium.copyWith(fontSize: 30, color: Theme.of(context).textTheme.bodyMedium?.color)),
//                ]
//            )),
//          ),

//        ],
//      );
//    }
// }


/**************************************/

// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:ride_sharing_user_app/util/dimensions.dart';
// import 'package:ride_sharing_user_app/util/styles.dart';

// class PagerContent extends StatelessWidget {
//   const PagerContent({
//     super.key, 
//     required this.image, 
//     required this.text1, 
//     required this.text2, 
//     required this.text3, 
//     required this.text4, 
//     required this.index
//   });
  
//   final String image;
//   final String text1;
//   final String text2;
//   final String text3;
//   final String text4;
//   final int index;

//   @override
//   Widget build(BuildContext context) {
//     final size = MediaQuery.of(context).size;
    
//     if(index != 3) {
//       return Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//        const Spacer(),

//           // Texte avec hauteur réduite
//          /*    Padding(
//             padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraLarge),
//             child: RichText(
//               text: TextSpan(
//                 children: [
//                   TextSpan(
//                    text: text1, 
//                     style: textMedium.copyWith(
//                       fontSize: 24, // Réduit de 30 à 24
//                       color: Theme.of(context).primaryColor
//                     )
//                   ),
//                   TextSpan(
//                     text: text2, 
//                     style: textMedium.copyWith(
//                       fontSize: 24, // Réduit de 30 à 24
//                       color: Theme.of(context).textTheme.bodyMedium?.color
//                     )
//                   ),
//                   TextSpan(
//                     text: text3, 
//                     style: textMedium.copyWith(
//                       fontSize: 24, // Réduit de 30 à 24
//                       color: Theme.of(context).primaryColor
//                     )
//                   ),
//                   TextSpan(
//                     text: text4, 
//                     style: textMedium.copyWith(
//                       fontSize: 24, // Réduit de 30 à 24
//                       color: Theme.of(context).textTheme.bodyMedium?.color
//                     )
//                   ),
//                 ]
//               )
//             ),
//           ),

//           const Spacer(), */

//           // Image avec hauteur contrôlée
//           Padding(
//             padding: EdgeInsets.only(
//               left: index == 1 ? Dimensions.paddingSizeSmall : 0
//             ),
//             child: Image.asset(
//               image,
//               width: Get.width,
//               height: size.height * 0.35, // Hauteur fixe de 30% de l'écran
//               fit: BoxFit.contain,
//             ),
//           ),

//           SizedBox(height: size.height * 0.03)
//         ],
//       );
//     }

//     // Dernière page
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         SizedBox(height: size.height * 0.02),

//         Image.asset(
//           image,
//           height: size.height * 0.25,
//           width: Get.width,
//           fit: BoxFit.contain,
//         ),
        
//         const SizedBox(height: Dimensions.paddingSizeLarge),

//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeExtraLarge),
//           child: RichText(
//             text: TextSpan(
//               children: [
//                 TextSpan(
//                   text: text1, 
//                   style: textMedium.copyWith(
//                     fontSize: 24,
//                     color: Theme.of(context).primaryColor
//                   )
//                 ),
//                 TextSpan(
//                   text: text2, 
//                   style: textMedium.copyWith(
//                     fontSize: 24,
//                     color: Theme.of(context).textTheme.bodyMedium?.color
//                   )
//                 ),
//                 TextSpan(
//                   text: text3, 
//                   style: textMedium.copyWith(
//                     fontSize: 24,
//                     color: Theme.of(context).primaryColor
//                   )
//                 ),
//                 TextSpan(
//                   text: text4, 
//                   style: textMedium.copyWith(
//                     fontSize: 24,
//                     color: Theme.of(context).textTheme.bodyMedium?.color
//                   )
//                 ),
//               ]
//             )
//           ),
//         ),

//         const Spacer(),
//       ],
//     );
//   }
// }




import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ride_sharing_user_app/util/dimensions.dart';
import 'package:ride_sharing_user_app/util/styles.dart';

class PagerContent extends StatelessWidget {
  const PagerContent({
    super.key, 
    required this.image, 
    required this.text1, 
    required this.text2, 
    required this.text3, 
    required this.text4, 
    required this.index
  });
  
  final String image;
  final String text1;
  final String text2;
  final String text3;
  final String text4;
  final int index;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    
    if(index != 3) {
      return Stack(
        children: [
          // Image en fond d'écran
          Positioned.fill(
            child: Image.asset(
              image,
              fit: BoxFit.contain, // L'image couvre tout l'espace
              width: Get.width ,
              height: size.height,
            ),
          ),
          
       
        ],
      );
    }

    // Dernière page avec image en fond
    return Stack(
      children: [
        // Image en fond d'écran
        Positioned.fill(
          child: Image.asset(
            image,
            fit: BoxFit.cover,
            width: Get.width,
            height: size.height,
          ),
        ),
        
      
      ],
    );
  }
}